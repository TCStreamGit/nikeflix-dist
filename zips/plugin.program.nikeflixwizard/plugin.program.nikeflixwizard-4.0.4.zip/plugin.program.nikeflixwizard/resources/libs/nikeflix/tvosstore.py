# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix
"""tvOS: Kodi's stored copies of userdata *.xml (NikeFlix 4.1.4).

On tvOS Kodi keeps every userdata *.xml in NSUserDefaults and reads that copy before the file on disk (TVOSFile,
Kodi 21 Omega source). The installer wipes and extracts with plain file IO, so after a clean install Kodi kept showing
the OLD profiles, skin and settings from its store while the new build sat on disk (Apple TV, 2026-11-21).

`stale_copies` finds every userdata xml whose copy as Kodi reads it differs from the file on disk, or that exists only
in Kodi's store. Deleting such a path through Kodi's file layer removes the stored copy only: when the stored copy
exists, TVOSFile::Delete removes the key and never touches the disk file. Afterwards the installer closes Kodi without
a save (os._exit), so nothing old is written back. `vfs` is injected: real Kodi in kodi_glue, a fake in tests.
"""
import os

SKIP_DIRS = ("Thumbnails/", "Database/", "Savestates/", "library/", "playlists/")
TOP_FILES = ("guisettings.xml", "favourites.xml", "sources.xml", "RssFeeds.xml", "mediasources.xml", "passwords.xml",
             "upnpserver.xml", "advancedsettings.xml", "playercorefactory.xml", "profiles.xml")


def candidates(userdata, vfs, addon_ids, keep=()):
    """Relative userdata paths to compare: every xml on disk or listed by Kodi in a directory that exists on disk,
    plus the top-level files and each add-on's settings.xml in the master and every profile folder."""
    out = set()
    for dp, _dn, fn in os.walk(userdata):
        rel = os.path.relpath(dp, userdata).replace("\\", "/")
        rel = "" if rel == "." else rel + "/"
        if rel.startswith(SKIP_DIRS):
            continue
        for f in set(fn) | set(vfs.listdir(rel)):
            if f.lower().endswith(".xml"):
                out.add(rel + f)
    pdir = os.path.join(userdata, "profiles")
    roots = [""] + (["profiles/%s/" % d for d in sorted(os.listdir(pdir))] if os.path.isdir(pdir) else [])
    for root in roots:
        out.update(root + f for f in TOP_FILES)
        out.update("%saddon_data/%s/settings.xml" % (root, a) for a in addon_ids)
    return sorted(p for p in out if p not in set(keep))


def stale_copies(userdata, vfs, addon_ids, keep=()):
    stale = []
    for rel in candidates(userdata, vfs, addon_ids, keep):
        if not vfs.exists(rel):
            continue
        try:
            with open(os.path.join(userdata, rel), "rb") as fh:
                disk = fh.read()
        except OSError:
            disk = None
        if disk is not None and vfs.read(rel) == disk:
            continue
        stale.append(rel)
    return stale


def drop_stale(userdata, vfs, addon_ids, keep=()):
    """Returns {"removed": n, "failed": [paths]} (paths only, never contents)."""
    removed, failed = 0, []
    for rel in stale_copies(userdata, vfs, addon_ids, keep):
        if vfs.delete(rel):
            removed += 1
        else:
            failed.append(rel)
    return {"removed": removed, "failed": failed}

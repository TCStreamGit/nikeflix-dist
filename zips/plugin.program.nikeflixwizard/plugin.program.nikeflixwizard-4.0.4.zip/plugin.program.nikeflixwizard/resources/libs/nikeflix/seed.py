# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Install the build's ``Addons33.db`` seed (T23 implementing the T24 mechanism, platform UPDATE-ORIGIN.md §2).

Kodi registers an add-on that appears by extraction with ``origin=''`` and ``enabled=0``; such an add-on
never receives a NikeFlix update. The build therefore ships a generated seed (``userdata/Database/Addons33.db``
inside the build ZIP) with ``origin=repository.NikeFlix``, ``enabled=1`` for every M add-on, the DIS rows and
the ``update_rules`` value 1 (UR-OFF) rows.

The wizard runs inside Kodi, which holds the live ``Addons33.db`` open. Instead of overwriting the file, the
seed's rows replace the live tables' rows in **one SQLite transaction** (``apply_seed``); Kodi is then
force-closed by the wizard. At the next start Kodi's startup sync keeps every seeded row (origin authoritative),
adds rows for system add-ons, and removes rows whose folder is gone.

``verify_seed`` is the post-install check (the wizard-side equivalent of ``addons_db_seed check``).
"""
import datetime as _dt
import os
import sqlite3

DB_NAME = "Addons33.db"
DB_VERSION = 33
TABLES = ("addons", "repo", "addonlinkrepo", "update_rules", "package", "installed")
RULE_USER_DISABLED_AUTO_UPDATE = 1
NIKEFLIX_ORIGIN = "repository.NikeFlix"


class SeedError(Exception):
    pass


def _columns(con, schema, table):
    rows = con.execute("PRAGMA {0}.table_info({1})".format(schema, table)).fetchall()
    return [r[1] for r in rows]


def _version(con, schema):
    try:
        row = con.execute("SELECT idVersion FROM {0}.version".format(schema)).fetchone()
    except sqlite3.DatabaseError as exc:
        raise SeedError("no version table in {0}: {1}".format(schema, exc))
    return row[0] if row else None


def check_seed_file(seed_path):
    """Validate a seed on its own: Kodi 21 v33 schema with the expected tables and an ``installed`` table."""
    if not os.path.isfile(seed_path):
        raise SeedError("seed file missing")
    con = sqlite3.connect("file:{0}?mode=ro".format(seed_path.replace("\\", "/")), uri=True)
    try:
        if _version(con, "main") != DB_VERSION:
            raise SeedError("seed is not an Addons{0}.db".format(DB_VERSION))
        for t in TABLES:
            if not _columns(con, "main", t):
                raise SeedError("seed lacks table {0}".format(t))
        n = con.execute("SELECT COUNT(*) FROM installed").fetchone()[0]
        if n == 0:
            raise SeedError("seed has no installed rows")
        return n
    finally:
        con.close()


def apply_seed(live_path, seed_path, timeout=30.0):
    """Replace the live DB's rows with the seed's rows in one transaction. Returns ``{table: rows}``."""
    check_seed_file(seed_path)
    if not os.path.isfile(live_path):
        raise SeedError("live Addons DB missing")
    con = sqlite3.connect(live_path, timeout=timeout, isolation_level=None)
    try:
        con.execute("ATTACH DATABASE ? AS seed", (seed_path,))
        if _version(con, "main") != DB_VERSION:
            raise SeedError("live DB is not Addons{0}.db (unsupported Kodi version)".format(DB_VERSION))
        for t in TABLES:
            if _columns(con, "main", t) != _columns(con, "seed", t):
                raise SeedError("schema differs for table {0}".format(t))
        counts = {}
        con.execute("BEGIN IMMEDIATE")
        try:
            for t in TABLES:
                con.execute("DELETE FROM main.{0}".format(t))
                con.execute("INSERT INTO main.{0} SELECT * FROM seed.{0}".format(t))
                counts[t] = con.execute("SELECT COUNT(*) FROM main.{0}".format(t)).fetchone()[0]
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
        con.execute("DETACH DATABASE seed")
        return counts
    finally:
        con.close()


MERGE_TABLES = ("installed", "update_rules")


def merge_seed(live_path, seed_path, timeout=30.0):
    """NikeFlix 4.1.7, the in-place update (a lived-in device): the build's rows replace only the rows of the build's
    own add-ons in ``installed`` and ``update_rules``. Every other row is kept: Fen 4 (installed by the wizard outside
    the build), anything the household added, and Kodi's repository caches. ``apply_seed`` (the whole tables) stays the
    clean install's step. 4.1.5/4.1.6 used apply_seed in place too, which dropped Fen's row: Kodi then re-registered
    Fen disabled while its service ran ("Unknown addon id plugin.video.fen" every 10 s, Apple TV 2026-11-22).
    Returns ``{table: rows merged}``."""
    check_seed_file(seed_path)
    if not os.path.isfile(live_path):
        raise SeedError("live Addons DB missing")
    con = sqlite3.connect(live_path, timeout=timeout, isolation_level=None)
    try:
        con.execute("ATTACH DATABASE ? AS seed", (seed_path,))
        if _version(con, "main") != DB_VERSION:
            raise SeedError("live DB is not Addons{0}.db (unsupported Kodi version)".format(DB_VERSION))
        cols = {}
        for t in MERGE_TABLES:
            live_cols = _columns(con, "main", t)
            if live_cols != _columns(con, "seed", t):
                raise SeedError("schema differs for table {0}".format(t))
            cols[t] = ", ".join(c for c in live_cols if c != "id")
        counts = {}
        con.execute("BEGIN IMMEDIATE")
        try:
            for t in MERGE_TABLES:
                con.execute("DELETE FROM main.{0} WHERE addonID IN (SELECT addonID FROM seed.{0})".format(t))
                con.execute("INSERT INTO main.{0} ({1}) SELECT {1} FROM seed.{0}".format(t, cols[t]))
                counts[t] = con.execute("SELECT COUNT(*) FROM seed.{0}".format(t)).fetchone()[0]
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
        con.execute("DETACH DATABASE seed")
        return counts
    finally:
        con.close()


def addon_row(live_path, addon_id):
    """``(enabled, origin, disabledReason)`` of one ``installed`` row, or None."""
    con = sqlite3.connect("file:{0}?mode=ro".format(live_path.replace("\\", "/")), uri=True, timeout=10.0)
    try:
        row = con.execute("SELECT enabled, origin, disabledReason FROM installed WHERE addonID=?", (addon_id,)).fetchone()
        return tuple(row) if row else None
    finally:
        con.close()


def verify_seed(live_path, seed_path):
    """Return a list of drift strings (empty = the live DB carries every seeded origin, flag and rule)."""
    drift = []
    con = sqlite3.connect(live_path, timeout=10.0)
    try:
        con.execute("ATTACH DATABASE ? AS seed", (seed_path,))
        live = {r[0]: r[1:] for r in con.execute(
            "SELECT addonID, enabled, origin, disabledReason FROM main.installed")}
        for aid, enabled, origin, reason in con.execute(
                "SELECT addonID, enabled, origin, disabledReason FROM seed.installed"):
            got = live.get(aid)
            if got is None:
                drift.append("{0}: missing installed row".format(aid))
            elif (int(got[0]), got[1], int(got[2])) != (int(enabled), origin, int(reason)):
                drift.append("{0}: enabled/origin/disabledReason {1} != seed {2}".format(
                    aid, tuple(got), (enabled, origin, reason)))
        live_rules = set(con.execute("SELECT addonID, updateRule FROM main.update_rules"))
        for row in con.execute("SELECT addonID, updateRule FROM seed.update_rules"):
            if tuple(row) not in live_rules:
                drift.append("{0}: missing update rule {1}".format(row[0], row[1]))
        con.execute("DETACH DATABASE seed")
    finally:
        con.close()
    return drift


def seeded_ids(seed_path):
    con = sqlite3.connect("file:{0}?mode=ro".format(seed_path.replace("\\", "/")), uri=True)
    try:
        return {r[0] for r in con.execute("SELECT addonID FROM installed")}
    finally:
        con.close()


def register_addon(live_path, addon_id, origin="", enabled=True, rule=None, now=None):
    """Insert (or update the enabled flag of) one ``installed`` row, and optionally an update rule.

    Used for add-ons installed outside the seed (Fen 4, CX-LIC: origin '' and rule 1). Kodi keeps an existing
    row across restarts, so the add-on is enabled without a JSON-RPC call or a dialog.
    """
    now = now or _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    con = sqlite3.connect(live_path, timeout=30.0, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        try:
            row = con.execute("SELECT id FROM installed WHERE addonID=?", (addon_id,)).fetchone()
            if row:
                con.execute("UPDATE installed SET enabled=?, disabledReason=0, origin=? WHERE addonID=?",
                            (1 if enabled else 0, origin, addon_id))
            else:
                con.execute("INSERT INTO installed (addonID, enabled, installDate, lastUpdated, lastUsed, origin, "
                            "disabledReason) VALUES (?, ?, ?, ?, NULL, ?, 0)",
                            (addon_id, 1 if enabled else 0, now, now, origin))
            if rule is not None:
                con.execute("INSERT OR IGNORE INTO update_rules (addonID, updateRule) VALUES (?, ?)",
                            (addon_id, int(rule)))
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
    finally:
        con.close()

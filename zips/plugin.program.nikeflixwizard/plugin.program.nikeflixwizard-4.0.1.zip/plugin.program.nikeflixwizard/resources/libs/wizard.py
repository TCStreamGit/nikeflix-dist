################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcgui

import os

from resources.libs import check
from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common.config import CONFIG


class Wizard:
    """NikeFlix clean build install (T23). The flow lives in resources.libs.nikeflix.installer."""

    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        self.dialogProgress = xbmcgui.DialogProgress()

    def build(self, name):
        from resources.libs import install
        from resources.libs.nikeflix import installer
        from resources.libs.nikeflix import kodi_glue

        if not kodi_glue.is_master():
            self.dialog.ok(CONFIG.ADDONTITLE, 'Builds can only be installed from the master profile.')
            return False
        entry = check.build_entry(name)
        if not entry:
            self.dialog.ok(CONFIG.ADDONTITLE, 'Build "{0}" is not available in the NikeFlix feed.'.format(name))
            return False

        self.dialogProgress.create(CONFIG.ADDONTITLE, 'NikeFlix {0}'.format(entry['version']))
        env = kodi_glue.InstallEnv(CONFIG, self.dialog, self.dialogProgress)
        try:
            report = installer.install_build(env, entry, keep=install.keep_options())
        except installer.InstallAborted as e:
            self.dialogProgress.close()
            logging.log('[Build Install] aborted: {0}'.format(e), level=xbmc.LOGINFO)
            self.dialog.ok(CONFIG.ADDONTITLE, 'Install stopped: {0}'.format(e))
            return False
        self.dialogProgress.close()

        if 'done' not in report['steps']:
            self.dialog.ok(CONFIG.ADDONTITLE, 'The install did not finish (see the wizard log). Kodi will now close.')
            tools.kill_kodi(over=True)
            return False

        CONFIG.set_setting('buildname', entry['name'])
        CONFIG.set_setting('buildversion', entry['version'])
        CONFIG.set_setting('latestversion', entry['version'])
        CONFIG.set_setting('installed', 'true')
        CONFIG.set_setting('extract', '100')
        CONFIG.set_setting('errors', str(len(report['extract']['errors'])))
        logging.log('[Build Install] {0} {1}: steps={2} seed_drift={3} fen={4} extract_errors={5}'.format(
            entry['name'], entry['version'], ','.join(report['steps']), len(report['seed_drift']),
            report['fen'], len(report['extract']['errors'])), level=xbmc.LOGINFO)

        msg = 'NikeFlix {0} is installed.'.format(entry['version'])
        if report['seed_drift'] or report['extract']['errors']:
            msg += '[CR]Warnings: {0} seed, {1} file(s) not written (see the wizard log).'.format(
                len(report['seed_drift']), len(report['extract']['errors']))
        if report['fen'] == 'unavailable':
            msg += '[CR]Fen 4 fallback unavailable (download or verification failed).'
        msg += '[CR]Kodi will now close. Start it again to finish.'
        self.dialog.ok(CONFIG.ADDONTITLE, msg)
        tools.kill_kodi(over=True)
        return True

    def fen(self):
        """Install / repair the Fen 4 fallback (CX-LIC) from its author's commit-pinned URL."""
        from resources.libs.nikeflix import fen as nffen
        from resources.libs.nikeflix import kodi_glue

        if not kodi_glue.is_master():
            self.dialog.ok(CONFIG.ADDONTITLE, 'Fen 4 can only be installed from the master profile.')
            return False
        if not self.dialog.yesno(CONFIG.ADDONTITLE,
                                 'Download Fen {0} from its author and verify it against the pinned hash?'.format(nffen.FEN_VERSION),
                                 nolabel='Cancel', yeslabel='Install'):
            return False
        self.dialogProgress.create(CONFIG.ADDONTITLE, 'Fen {0}'.format(nffen.FEN_VERSION))
        result = nffen.install(CONFIG.ADDONS, CONFIG.MASTERPROFILE, os.path.join(CONFIG.PLUGIN_DATA, 'fen'),
                               addons_db=os.path.join(CONFIG.DATABASE, 'Addons33.db'),
                               log=lambda m: logging.log(m, level=xbmc.LOGINFO))
        self.dialogProgress.close()
        if result['status'] == 'installed':
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled",'
                                '"params":{"addonid":"plugin.video.fen","enabled":true}}')
            self.dialog.ok(CONFIG.ADDONTITLE, 'Fen {0} installed and verified.'.format(nffen.FEN_VERSION))
            return True
        self.dialog.ok(CONFIG.ADDONTITLE, 'Fen 4 fallback unavailable: {0}'.format(result.get('reason', '')))
        return False

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Update-control settings in every profile's ``guisettings.xml`` (T23; T24 correction, plan §B7 item 2).

Authority: the build's **generated** guisettings (platform ``nfbuild generate``; ``nfbuild validate`` blocks
``addons.updatemode=1`` and ``general.addonupdates`` other than 0). The wizard re-asserts and verifies the two
keys after extraction in the master ``userdata/guisettings.xml`` and in every
``userdata/profiles/*/guisettings.xml`` (defence in depth). The wizard then force-closes Kodi, so the running
session never writes its old in-memory values over these files.

* ``addons.updatemode=0`` (OFFICIAL_ONLY; 1 = ANY repository, forbidden);
* ``general.addonupdates=0`` (install NikeFlix updates automatically).

A profile folder without its own ``guisettings.xml`` uses Kodi's defaults, which are 0 for both keys; it is
reported as ``default`` and left alone.
"""
import os
import xml.etree.ElementTree as ET

REQUIRED = {"addons.updatemode": "0", "general.addonupdates": "0"}


def guisettings_files(userdata):
    """Master guisettings plus one per profile folder: ``[(label, path_or_None)]``."""
    out = [("master", os.path.join(userdata, "guisettings.xml"))]
    pdir = os.path.join(userdata, "profiles")
    if os.path.isdir(pdir):
        for name in sorted(os.listdir(pdir)):
            full = os.path.join(pdir, name)
            if os.path.isdir(full) and not os.path.islink(full):
                gs = os.path.join(full, "guisettings.xml")
                out.append(("profiles/" + name, gs if os.path.isfile(gs) else None))
    return out


def enforce_file(path, required=None):
    """Set the required keys in one guisettings.xml. Returns the list of keys that were changed."""
    required = REQUIRED if required is None else required
    tree = ET.parse(path)
    root = tree.getroot()
    if root.tag != "settings":
        raise ValueError("not a Kodi settings file")
    changed = []
    for key, value in required.items():
        node = None
        for s in root.findall("setting"):
            if s.get("id") == key:
                node = s
                break
        if node is None:
            node = ET.SubElement(root, "setting", {"id": key})
            node.text = value
            changed.append(key)
        elif (node.text or "").strip() != value or node.get("default") is not None:
            node.text = value
            if "default" in node.attrib:
                del node.attrib["default"]
            changed.append(key)
    if changed:
        tmp = path + ".nikeflix-tmp"
        tree.write(tmp, encoding="utf-8", xml_declaration=True)
        os.replace(tmp, path)
    return changed


def read_values(path, keys=None):
    keys = list(REQUIRED) if keys is None else keys
    root = ET.parse(path).getroot()
    vals = {}
    for s in root.findall("setting"):
        if s.get("id") in keys:
            vals[s.get("id")] = (s.text or "").strip()
    return vals


def enforce_all(userdata, required=None):
    """Enforce in master + all profiles. Returns ``[{"profile", "status", "changed"}]`` (no paths, no values)."""
    report = []
    for label, path in guisettings_files(userdata):
        if path is None or not os.path.isfile(path):
            report.append({"profile": label, "status": "default", "changed": []})
            continue
        try:
            changed = enforce_file(path, required)
            report.append({"profile": label, "status": "set" if changed else "ok", "changed": changed})
        except (ET.ParseError, ValueError, OSError):
            report.append({"profile": label, "status": "error", "changed": []})
    return report

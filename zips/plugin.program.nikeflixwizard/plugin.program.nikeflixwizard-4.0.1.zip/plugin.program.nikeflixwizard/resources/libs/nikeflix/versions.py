# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Semantic version comparison for build and wizard updates (T23; plan A6 item 7).

The legacy wizard compared versions as strings, so ``"3.10.0" > "3.9.0"`` was False and ``"4.0.0" > "10.0"``
was True. This module orders versions the way Kodi orders add-on versions:

* optional epoch ``N:`` (higher epoch wins);
* the main part is split into numeric and alphabetic runs; numbers compare numerically, a missing component
  counts as 0 (``1.0`` == ``1.0.0``), and a number sorts above a letter run;
* a ``~`` suffix is a pre-release (``1.0~beta2`` < ``1.0``; ``1.0~beta10`` > ``1.0~beta2``);
* ``+metadata`` (``1.16.0+matrix.1``) is ignored.
"""
import re

_TOKEN = re.compile(r"\d+|[A-Za-z]+")
_VALID = re.compile(r"^(\d+:)?[0-9A-Za-z][0-9A-Za-z.\-_]*(~[0-9A-Za-z.\-_]+)?(\+[0-9A-Za-z.\-_]+)?$")


def _tokens(text):
    out = []
    for tok in _TOKEN.findall(text):
        out.append((1, int(tok), "") if tok.isdigit() else (0, 0, tok.lower()))
    return out


def parse(version):
    """Return a comparable key for ``version``; raise ValueError if it is not a version string."""
    if not isinstance(version, str):
        raise ValueError("version must be a string")
    v = version.strip()
    if not v or not _VALID.match(v):
        raise ValueError("not a version: {0!r}".format(version))
    v = v.split("+", 1)[0]
    epoch = 0
    if ":" in v:
        e, v = v.split(":", 1)
        epoch = int(e)
    main, _, pre = v.partition("~")
    return epoch, _tokens(main), _tokens(pre) if pre else None


def _cmp_tokens(a, b):
    n = max(len(a), len(b))
    for i in range(n):
        x = a[i] if i < len(a) else (1, 0, "")
        y = b[i] if i < len(b) else (1, 0, "")
        if x != y:
            return -1 if x < y else 1
    return 0


def compare(a, b):
    """-1, 0 or 1 like ``cmp(a, b)``. Raises ValueError on an invalid version."""
    ea, ma, pa = parse(a)
    eb, mb, pb = parse(b)
    if ea != eb:
        return -1 if ea < eb else 1
    c = _cmp_tokens(ma, mb)
    if c:
        return c
    if pa is None and pb is None:
        return 0
    if pa is None:
        return 1  # release > pre-release
    if pb is None:
        return -1
    return _cmp_tokens(pa, pb)


def is_valid(version):
    try:
        parse(version)
        return True
    except ValueError:
        return False


def is_newer(candidate, installed):
    """True only if ``candidate`` is a valid version strictly newer than ``installed``.

    An empty/invalid installed version means "nothing installed": any valid candidate is newer.
    An invalid candidate is never newer (fail closed).
    """
    if not is_valid(candidate):
        return False
    if not installed or not is_valid(installed):
        return True
    return compare(candidate, installed) > 0

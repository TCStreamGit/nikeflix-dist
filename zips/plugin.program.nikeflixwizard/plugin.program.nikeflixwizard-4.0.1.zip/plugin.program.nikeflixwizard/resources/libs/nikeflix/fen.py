# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Fen 4 external installer (T23; CX-LIC, platform FEN4-VERIFICATION.md §9 and ORIGIN-WATCHDOG.md §3).

Fen 4 has no licence and the author allows personal use only, so NikeFlix never bundles, redistributes or
patches it. On the device, this installer:

1. downloads ``plugin.video.fen-4.0.46.zip`` from the author's **commit-pinned** URL (fallback: the author's
   GitHub Pages URL; nothing else);
2. verifies the exact size, sha256 and git blob; any mismatch rejects the bytes (nothing is extracted);
3. validates the archive (every member under ``plugin.video.fen/``, no unsafe paths, ``addon.xml`` id and
   version) by reading it as **data**; no Fen code is imported or executed;
4. extracts into a work folder and swaps it into ``addons/plugin.video.fen`` with two renames;
5. writes the receipt the T25 origin watchdog reads:
   ``special://masterprofile/addon_data/service.nikeflix/fen-install.json`` = ``{"id", "version", "sha256", ...}``;
6. registers Fen in ``Addons33.db`` (``origin=''``, enabled, update rule 1) so Kodi neither disables nor
   auto-updates it.

If the download or a check fails, the result is ``fallback unavailable``: a status file is written next to the
receipt and **no substitute** is installed.
"""
import datetime as _dt
import json
import os
import shutil
import uuid
import zipfile
import xml.etree.ElementTree as ET

from resources.libs.nikeflix import integrity

FEN_ID = "plugin.video.fen"
FEN_VERSION = "4.0.46"
FEN_SHA256 = "565935ad7994878a17ce99c7455233a405b92557f1cb79d2b0b02e5fa30a2874"
FEN_GIT_BLOB = "86785a1e1e802b83f82294ffd104cae730430588"
FEN_SIZE = 1747933
FEN_URLS = (
    "https://raw.githubusercontent.com/Tikipeter/Tikipeter.github.io/e5c183e771e4/packages/plugin.video.fen-4.0.46.zip",
    "https://tikipeter.github.io/packages/plugin.video.fen-4.0.46.zip",
)
RECEIPT_REL = ("addon_data", "service.nikeflix", "fen-install.json")  # under special://masterprofile/
STATUS_REL = ("addon_data", "service.nikeflix", "fen-install-status.json")
MAX_DOWNLOAD = 16 * 1024 * 1024
RULE_USER_DISABLED_AUTO_UPDATE = 1


def receipt_path(master_userdata):
    return os.path.join(master_userdata, *RECEIPT_REL)


def status_path(master_userdata):
    return os.path.join(master_userdata, *STATUS_REL)


def urllib_fetch(url, dest, max_bytes=MAX_DOWNLOAD, timeout=30):
    """Default HTTPS downloader (stdlib only). Raises on any error or when the size cap is exceeded."""
    import urllib.request

    if not url.startswith("https://"):
        raise IOError("HTTPS only")
    req = urllib.request.Request(url, headers={"User-Agent": "NikeFlixWizard/4 (Kodi)"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as out:
        total = 0
        while True:
            chunk = resp.read(64 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise IOError("download exceeds size cap")
            out.write(chunk)


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
    os.replace(tmp, path)


def _now():
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def check_addon_xml(zip_path):
    """Read ``plugin.video.fen/addon.xml`` as data; raise ArchiveError unless id and version match."""
    with zipfile.ZipFile(zip_path) as zf:
        try:
            raw = zf.read(FEN_ID + "/addon.xml")
        except KeyError:
            raise integrity.ArchiveError("addon.xml missing")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise integrity.ArchiveError("addon.xml unreadable")
    if root.get("id") != FEN_ID or root.get("version") != FEN_VERSION:
        raise integrity.ArchiveError("addon.xml id/version is not {0} {1}".format(FEN_ID, FEN_VERSION))


def _swap_in(addons_dir, new_dir):
    """Replace ``addons/plugin.video.fen`` with ``new_dir`` (two renames, undo on failure)."""
    target = os.path.join(addons_dir, FEN_ID)
    old = None
    if os.path.exists(target):
        old = os.path.join(os.path.dirname(os.path.dirname(new_dir)), "old", FEN_ID)
        os.makedirs(os.path.dirname(old), exist_ok=True)
        os.rename(target, old)
    try:
        os.rename(new_dir, target)
    except OSError:
        if old is not None:
            os.rename(old, target)
        raise


def install(addons_dir, master_userdata, workdir, fetch=None, addons_db=None, urls=FEN_URLS,
            expected=None, log=None, now=None):
    """Download, verify and install Fen 4. Returns ``{"status": "installed"|"unavailable", ...}``."""
    fetch = fetch or urllib_fetch
    log = log or (lambda msg: None)
    exp = {"sha256": FEN_SHA256, "size": FEN_SIZE, "git_blob": FEN_GIT_BLOB}
    exp.update(expected or {})
    os.makedirs(workdir, exist_ok=True)
    zpath = os.path.join(workdir, "{0}-{1}.zip".format(FEN_ID, FEN_VERSION))
    attempts, verified_url = [], None
    for url in urls:
        try:
            if os.path.exists(zpath):
                os.remove(zpath)
            fetch(url, zpath)
            integrity.verify_file(zpath, exp["sha256"], size=exp["size"], git_blob=exp["git_blob"])
            verified_url = url
            break
        except Exception as exc:  # download error or verification failure: try the next author URL
            attempts.append({"url": url, "error": str(exc)[:200]})
            log("[Fen] {0}: {1}".format(url, exc))
            if os.path.exists(zpath):
                os.remove(zpath)
    result = {"id": FEN_ID, "version": FEN_VERSION, "attempts": attempts, "checked": now or _now()}
    if verified_url is None:
        result.update(status="unavailable", reason="download or verification failed; fallback unavailable "
                                                   "(no substitute installed)")
        _write_json(status_path(master_userdata), result)
        return result
    work = os.path.join(addons_dir, ".nikeflix-fen-" + uuid.uuid4().hex[:8])
    try:
        members = integrity.inspect_archive(zpath, single_root=FEN_ID, max_unpacked=64 * 1024 * 1024)
        check_addon_xml(zpath)
        new_root = os.path.join(work, "new")
        integrity.extract_members(zpath, members, new_root)
        _swap_in(addons_dir, os.path.join(new_root, FEN_ID))
    except Exception as exc:
        result.update(status="unavailable", reason="archive rejected: {0}".format(str(exc)[:200]))
        _write_json(status_path(master_userdata), result)
        return result
    finally:
        shutil.rmtree(work, ignore_errors=True)
        if os.path.exists(zpath):
            os.remove(zpath)
    receipt = {"id": FEN_ID, "version": FEN_VERSION, "sha256": exp["sha256"], "git_blob": exp["git_blob"],
               "size": exp["size"], "source_url": verified_url, "installed": now or _now(),
               "installer": "plugin.program.nikeflixwizard"}
    _write_json(receipt_path(master_userdata), receipt)
    result.update(status="installed", source_url=verified_url)
    if addons_db and os.path.isfile(addons_db):
        from resources.libs.nikeflix import seed
        try:
            seed.register_addon(addons_db, FEN_ID, origin="", enabled=True, rule=RULE_USER_DISABLED_AUTO_UPDATE)
            result["registered"] = True
        except Exception as exc:
            result["registered"] = False
            log("[Fen] Addons DB registration failed: {0}".format(exc))
    _write_json(status_path(master_userdata), result)
    return result

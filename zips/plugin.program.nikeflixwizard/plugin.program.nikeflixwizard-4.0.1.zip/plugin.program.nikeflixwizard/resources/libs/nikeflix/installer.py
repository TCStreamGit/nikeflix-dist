# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""NikeFlix build install flow (T23): verify -> back up -> wipe -> extract -> seed -> settings -> Fen -> restart.

Seeds: the master ``Addons33.db`` is applied to Kodi's live DB; every other profile's own seed is extracted with the
build and gets the same registrations (``_profile_seeds``, T23/T61).

Order matters: everything that can fail without side effects (download, sha256, archive inspection, seed
check, Kodi version) happens **before** the backup and the wipe. A sha256 mismatch aborts with nothing changed.

``env`` is an adapter (Kodi glue in ``kodi_glue.InstallEnv``; a fake in the tests) providing:

* paths: ``home``, ``userdata`` (master), ``addons_dir``, ``live_addons_db``, ``staging`` (inside the kept
  wizard data folder, so the wipe never removes the downloaded build), ``wizard_id``, ``kodi_version``;
* ``download(url, dest, progress)``; ``progress(percent, text)`` -> False to cancel; ``log(msg)``;
* decisions: ``confirm_install(entry, compat)``, ``ask_backup(default_root)`` -> ``("backup", root)`` |
  ``("skip", None)`` | ``("cancel", None)``, ``confirm_backup_errors(report)``, ``want_fen()``;
* ``purge_locked(path)`` for files Kodi holds open; ``fen_fetch`` (optional) for the Fen installer.
"""
import json
import os
import shutil
import sqlite3
import xml.etree.ElementTree as ET
import zipfile

from resources.libs.nikeflix import feed
from resources.libs.nikeflix import fen
from resources.libs.nikeflix import integrity
from resources.libs.nikeflix import kodisettings
from resources.libs.nikeflix import seed
from resources.libs.nikeflix import seedpolicy
from resources.libs.nikeflix import wipe

BUILD_TOP = {"addons", "media", "userdata"}
SEED_MEMBER = ("userdata", "Database", seed.DB_NAME)


class InstallAborted(Exception):
    """Raised before anything was changed on the device (or when the user cancels)."""


def _is_wizard_member(parts, wizard_id):
    if len(parts) >= 2 and parts[0] == "addons" and parts[1] == wizard_id:
        return True
    for i in range(len(parts) - 1):
        if parts[i] == "addon_data" and parts[i + 1] == wizard_id:
            return True  # wizard state is master-only and owned by the running wizard
    return False


def _is_log(parts):
    return parts[-1].lower() in wipe.LOG_NAMES or parts[-1].lower().endswith(".log")


def addon_ids(members):
    ids = set()
    for _info, parts in members:
        if len(parts) == 3 and parts[0] == "addons" and parts[2] == "addon.xml":
            ids.add(parts[1])
    return ids


def prepare(env, entry):
    """Download and verify the build. Returns ``(zip_path, members, seed_path)``. No device change."""
    problems = feed.validate_build(entry)
    if problems:
        raise InstallAborted("feed entry rejected: " + "; ".join(problems))
    os.makedirs(env.staging, exist_ok=True)
    zpath = os.path.join(env.staging, "build.zip")
    seed_path = os.path.join(env.staging, seed.DB_NAME)
    for p in (zpath, seed_path):
        if os.path.exists(p):
            os.remove(p)
    env.download(entry["url"], zpath, env.progress)
    try:
        integrity.verify_file(zpath, entry["sha256"], size=entry.get("size"))
    except integrity.IntegrityError as exc:
        os.remove(zpath)
        raise InstallAborted("download rejected ({0}); nothing was changed".format(exc))
    try:
        members = integrity.inspect_archive(zpath, allowed_top=BUILD_TOP)
    except integrity.ArchiveError as exc:
        os.remove(zpath)
        raise InstallAborted("build archive rejected ({0}); nothing was changed".format(exc))
    _drop_seed_copies(env)
    seed_members = [(i, p) for i, p in members if tuple(p) == SEED_MEMBER]
    if not seed_members:
        os.remove(zpath)
        raise InstallAborted("build has no Addons33.db seed (T24); nothing was changed")
    integrity.extract_members(zpath, seed_members, env.staging, redirect=lambda parts: seed_path)
    try:
        seed.check_seed_file(seed_path)
    except seed.SeedError as exc:
        os.remove(zpath)
        raise InstallAborted("seed rejected ({0}); nothing was changed".format(exc))
    try:   # every profile's own seed, before anything is backed up or wiped (T23/T61, T24 policy)
        seedpolicy.validate_build(zpath, members, env.staging, env.wizard_id)
    except (seedpolicy.SeedPolicyError, zipfile.BadZipFile, ET.ParseError, sqlite3.DatabaseError) as exc:
        os.remove(zpath)
        _drop_seed_copies(env)
        raise InstallAborted("profile seeds rejected ({0}); nothing was changed".format(exc))
    return zpath, members, seed_path


def _drop_seed_copies(env):
    shutil.rmtree(os.path.join(env.staging, "seeds"), ignore_errors=True)


def _register_unseeded(db, ids, addons_dir):
    """Approved, explicitly documented exceptions only (seedpolicy.APPROVED_UNSEEDED); prepare() already refused
    any other shipped add-on without a seed row."""
    done = []
    for aid in ids:
        rule = seedpolicy.APPROVED_UNSEEDED.get(aid)
        if rule is not None and os.path.isdir(os.path.join(addons_dir, aid)):
            seed.register_addon(db, aid, origin=rule.get("origin", ""), enabled=True, rule=rule.get("rule"))
            done.append(aid)
    return done


def _profile_seeds(env, members, unseeded):
    """Per-profile ``Addons33.db`` seeds (T23/T61). NikeFlix profiles have their own databases, so the build ships
    one generated seed per profile at ``userdata/profiles/<dir>/Database/Addons33.db``. prepare() validated every
    one before the wipe (``seedpolicy.validate_build``); here the extracted copies get the same approved
    registrations as the master DB. Returns ``(seeds, profiles_without_seed)`` (the latter is always empty now)."""
    seeds, dirs = [], set()
    for _, parts in members:
        parts = tuple(parts)
        if len(parts) >= 3 and parts[:2] == ("userdata", "profiles"):
            dirs.add(parts[2])
        if len(parts) == 5 and parts[:2] == ("userdata", "profiles") and parts[3:] == ("Database", seed.DB_NAME):
            path = os.path.join(env.userdata, "profiles", parts[2], "Database", seed.DB_NAME)
            entry = {"profile": parts[2], "path": path}
            try:
                entry["rows"] = seed.check_seed_file(path)
                entry.update(status="ok", registered=_register_unseeded(path, unseeded, env.addons_dir))
            except seed.SeedError as exc:   # cannot happen after the pre-wipe check unless the disk failed
                entry.update(status="rejected", error=str(exc))
            seeds.append(entry)
    missing = sorted(dirs - {s["profile"] for s in seeds})
    return seeds, missing


def install_build(env, entry, keep=None):
    """Run the whole install. Returns the report dict (also written to the staging folder as JSON)."""
    report = {"build": entry.get("name"), "version": entry.get("version"), "steps": []}

    compat = feed.kodi_compat(entry.get("kodi"), env.kodi_version)
    if compat == "block":
        raise InstallAborted("build is for Kodi {0}; this device runs {1}".format(entry.get("kodi"), env.kodi_version))
    if not env.confirm_install(entry, compat):
        raise InstallAborted("cancelled")

    zpath, members, seed_path = prepare(env, entry)
    report["steps"].append("verified sha256 and archive")

    choice, root = env.ask_backup(wipe.default_backup_root(env.home))
    if choice == "cancel":
        raise InstallAborted("cancelled")
    if choice == "backup":
        try:
            b = wipe.make_backup(env.home, root, progress=lambda n, rel: env.progress(0, "Backing up: {0} files".format(n)))
        except wipe.WipeError as exc:
            raise InstallAborted("backup failed ({0}); nothing was wiped".format(exc))
        report["backup"] = {"path": b["path"], "files": b["files"], "errors": b["errors"]}
        if b["errors"] and not env.confirm_backup_errors(b):
            raise InstallAborted("cancelled after backup errors; nothing was wiped")
        report["steps"].append("backup")
    else:
        report["backup"] = "declined"

    plan = wipe.plan_wipe(env.home, env.wizard_id, keep=keep)
    report["wipe_plan"] = wipe.summarize(plan)
    res = wipe.execute_wipe(plan, on_locked=env.purge_locked,
                            progress=lambda pct, rel: env.progress(pct, "Removing old setup"))
    report["wipe"] = {k: (len(v) if isinstance(v, list) else v) for k, v in res.items()}
    report["wipe_failed"] = res["failed"][:50]
    if res["cancelled"]:
        report["steps"].append("wipe cancelled")
        return report
    report["steps"].append("wipe")

    extract_errors = []
    written, skipped = integrity.extract_members(
        zpath, members, env.home,
        skip=lambda parts: tuple(parts) == SEED_MEMBER or _is_wizard_member(parts, env.wizard_id) or _is_log(parts),
        progress=lambda pct, rel: env.progress(pct, "Installing NikeFlix"),
        errors=extract_errors)
    report["extract"] = {"written": written, "skipped": skipped, "errors": extract_errors[:50]}
    report["steps"].append("extract")

    if os.path.isfile(env.live_addons_db):
        report["seed"] = seed.apply_seed(env.live_addons_db, seed_path)
    else:
        os.makedirs(os.path.dirname(env.live_addons_db), exist_ok=True)
        with open(seed_path, "rb") as src, open(env.live_addons_db, "wb") as dst:
            dst.write(src.read())
        report["seed"] = "copied"
    unseeded = sorted(addon_ids(members) - seed.seeded_ids(seed_path) - {env.wizard_id})
    report["unseeded_registered"] = _register_unseeded(env.live_addons_db, unseeded, env.addons_dir)
    report["seed_drift"] = seed.verify_seed(env.live_addons_db, seed_path)
    report["profile_seeds"], report["profile_seed_missing"] = _profile_seeds(env, members, unseeded)
    report["steps"].append("seed")

    report["kodi_settings"] = kodisettings.enforce_all(env.userdata)
    report["steps"].append("update settings")

    if env.want_fen():
        r = fen.install(env.addons_dir, env.userdata, os.path.join(env.staging, "fen"),
                        fetch=getattr(env, "fen_fetch", None), addons_db=env.live_addons_db, log=env.log)
        report["fen"] = r["status"]
        if r["status"] == "installed":
            for ps in report["profile_seeds"]:
                if ps.get("status") == "ok":
                    seed.register_addon(ps["path"], fen.FEN_ID, origin="", enabled=True,
                                        rule=fen.RULE_USER_DISABLED_AUTO_UPDATE)
                    ps["fen_registered"] = True
    else:
        report["fen"] = "skipped"

    for p in (zpath, seed_path):
        if os.path.exists(p):
            os.remove(p)
    _drop_seed_copies(env)
    report["steps"].append("done")
    with open(os.path.join(env.staging, "last-install.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, sort_keys=True, default=str)
    return report

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Wizard startup service (T23; T05 finding: no wizard modals on any profile, T02: no costly startup probes).

Contract:

* **Non-master profiles:** return immediately. No settings are read or written, nothing is shown, nothing is
  fetched (wizard state is master-only).
* **Master profile:** cheap checks only and **no dialog of any kind**. At most once per 24 h (setting
  ``update_check``), the feed is fetched in a background thread with a short timeout; the result is stored in
  the wizard settings and Home-window properties. A non-modal toast is shown only when the user enabled
  ``notify_updates`` (default off). The loop waits in ``waitForAbort`` steps of at most 1 s, so a profile
  switch or shutdown is never delayed.

``env`` (``kodi_glue.ServiceEnv`` in Kodi, a fake in tests) provides ``is_master()``, ``setting(id)``,
``set_setting(id, value)``, ``wait_for_abort(seconds)``, ``fetch_text(url, timeout)``, ``set_property(k, v)``,
``toast(msg)``, ``log(msg)``, ``now()`` (epoch seconds), ``build_name``, ``build_version``,
``wizard_version`` and ``buildfile``.
"""
import threading

from resources.libs.nikeflix import feed

CHECK_INTERVAL = 24 * 3600
FETCH_TIMEOUT = 5
MAX_WAIT = 30
PROP_BUILD = "nikeflixwizard.build_update"
PROP_WIZARD = "nikeflixwizard.wizard_update"


def due(last_epoch, now, interval=CHECK_INTERVAL):
    try:
        last = float(last_epoch or 0)
    except (TypeError, ValueError):
        last = 0.0
    return now - last >= interval or now < last


def evaluate(text, build_name, build_version, wizard_version):
    """Pure: ``{"build": newer build version or "", "wizard": newer wizard version or ""}``."""
    parsed = feed.parse(text)
    b = feed.update_available(parsed, build_name, build_version)
    w = feed.wizard_update_available(parsed, wizard_version)
    return {"build": b["version"] if b else "", "wizard": w["version"] if w else ""}


def run(env):
    if not env.is_master():
        env.log("[NikeFlix Wizard] non-master profile: idle (wizard state is master-only)")
        return "idle-non-master"
    if env.setting("update_check") == "false":
        return "update-check-off"
    now = env.now()
    if not due(env.setting("lastupdatecheck"), now):
        return "not-due"

    box = {}

    def worker():
        try:
            box["text"] = env.fetch_text(env.buildfile, FETCH_TIMEOUT)
        except Exception as exc:  # network errors are expected offline; never surface them as UI
            box["error"] = str(exc)[:200]

    t = threading.Thread(target=worker, name="nikeflixwizard-feed")
    t.daemon = True
    t.start()
    waited = 0
    while t.is_alive():
        if env.wait_for_abort(1):
            return "aborted"
        waited += 1
        if waited >= MAX_WAIT:
            env.log("[NikeFlix Wizard] feed check timed out")
            return "timeout"
    if "text" not in box:
        env.log("[NikeFlix Wizard] feed check failed: {0}".format(box.get("error", "")))
        return "fetch-failed"
    try:
        result = evaluate(box["text"], env.build_name, env.build_version, env.wizard_version)
    except feed.FeedError as exc:
        env.log("[NikeFlix Wizard] feed unreadable: {0}".format(exc))
        return "feed-invalid"
    env.set_setting("lastupdatecheck", str(int(now)))
    if result["build"]:
        env.set_setting("latestversion", result["build"])
    env.set_property(PROP_BUILD, result["build"])
    env.set_property(PROP_WIZARD, result["wizard"])
    if (result["build"] or result["wizard"]) and env.setting("notify_updates") == "true":
        what = "NikeFlix {0}".format(result["build"]) if result["build"] else "Wizard {0}".format(result["wizard"])
        env.toast("Update available: {0} (open the NikeFlix Wizard)".format(what))
    return "checked"

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Download integrity and safe archive handling (T23; plan F5).

* ``verify_file``: size, sha256 and (optionally) git-blob check of a downloaded file.
* ``inspect_archive``: rejects absolute, drive, backslash and ``..`` member paths, symlinks, duplicate
  members, members outside the allowed top-level folders, oversize archives and CRC failures.
* ``extract_members``: writes only validated members, re-checking every resolved target path.
"""
import hashlib
import os
import shutil
import stat
import zipfile

CHUNK = 1024 * 1024


class IntegrityError(Exception):
    pass


class ArchiveError(Exception):
    pass


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha1(path):
    """The git object id of a file's bytes (``git hash-object``)."""
    size = os.path.getsize(path)
    h = hashlib.sha1()
    h.update("blob {0}\0".format(size).encode("ascii"))
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_file(path, sha256, size=None, git_blob=None):
    """Raise IntegrityError unless the file matches every given expectation."""
    if not os.path.isfile(path):
        raise IntegrityError("file missing")
    actual_size = os.path.getsize(path)
    if size is not None and int(size) != actual_size:
        raise IntegrityError("size mismatch: expected {0}, got {1}".format(size, actual_size))
    actual = sha256_file(path)
    if not sha256 or actual != str(sha256).lower():
        raise IntegrityError("sha256 mismatch: expected {0}, got {1}".format(sha256, actual))
    if git_blob is not None:
        blob = git_blob_sha1(path)
        if blob != str(git_blob).lower():
            raise IntegrityError("git blob mismatch: expected {0}, got {1}".format(git_blob, blob))
    return actual


def member_parts(name):
    """Validated path components of a ZIP member name, or raise ArchiveError."""
    if not name or "\\" in name or "\x00" in name:
        raise ArchiveError("unsafe member name: {0!r}".format(name))
    if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        raise ArchiveError("absolute member path: {0!r}".format(name))
    parts = name.rstrip("/").split("/")
    for p in parts:
        if p in ("", ".", "..") or ":" in p:
            raise ArchiveError("unsafe member path: {0!r}".format(name))
    return parts


def _is_symlink(info):
    return stat.S_ISLNK(info.external_attr >> 16)


def inspect_archive(path, allowed_top=None, single_root=None, max_members=200000,
                    max_unpacked=8 * 1024 ** 3, test_crc=True):
    """Return ``[(ZipInfo, parts), ...]`` for every member; raise ArchiveError on any unsafe member."""
    try:
        zf = zipfile.ZipFile(path, "r")
    except (zipfile.BadZipFile, OSError) as exc:
        raise ArchiveError("not a ZIP archive: {0}".format(exc))
    with zf:
        infos = zf.infolist()
        if not infos:
            raise ArchiveError("empty archive")
        if len(infos) > max_members:
            raise ArchiveError("too many members")
        total, seen, out = 0, set(), []
        for info in infos:
            parts = member_parts(info.filename)
            if _is_symlink(info):
                raise ArchiveError("symlink member: {0!r}".format(info.filename))
            key = "/".join(parts).lower()
            if key in seen and not info.is_dir():
                raise ArchiveError("duplicate member: {0!r}".format(info.filename))
            seen.add(key)
            if allowed_top is not None and parts[0] not in allowed_top:
                raise ArchiveError("member outside {0}: {1!r}".format(sorted(allowed_top), info.filename))
            if single_root is not None and parts[0] != single_root:
                raise ArchiveError("member outside {0}/: {1!r}".format(single_root, info.filename))
            total += info.file_size
            if total > max_unpacked:
                raise ArchiveError("archive unpacks beyond the size limit")
            out.append((info, parts))
        if test_crc:
            bad = zf.testzip()
            if bad is not None:
                raise ArchiveError("CRC failure: {0!r}".format(bad))
    return out


def _inside(root, target):
    root = os.path.normcase(os.path.realpath(root))
    target = os.path.normcase(os.path.realpath(target))
    try:
        return os.path.commonpath([root, target]) == root
    except ValueError:
        return False


def extract_members(path, members, dest_root, skip=None, redirect=None, progress=None, errors=None):
    """Extract validated ``members`` (from inspect_archive) under ``dest_root``.

    ``skip(parts)`` -> True leaves a member out; ``redirect(parts)`` may return another absolute file path
    for a member. When ``errors`` is a list, a member that cannot be written (e.g. a file Kodi holds open) is
    recorded there and extraction continues; otherwise the OSError propagates. Returns ``(written, skipped)``.
    """
    written = skipped = 0
    total = len(members) or 1
    with zipfile.ZipFile(path, "r") as zf:
        for i, (info, parts) in enumerate(members):
            if skip is not None and skip(parts):
                skipped += 1
                continue
            target = redirect(parts) if redirect is not None else None
            redirected = target is not None
            if not redirected:
                target = os.path.join(dest_root, *parts)
                if not _inside(dest_root, target):
                    raise ArchiveError("member escapes the target: {0!r}".format(info.filename))
            if info.is_dir():
                if not redirected:
                    os.makedirs(target, exist_ok=True)
                continue
            parent = os.path.dirname(target)
            os.makedirs(parent, exist_ok=True)
            if not redirected and not _inside(dest_root, parent):
                raise ArchiveError("member escapes the target: {0!r}".format(info.filename))
            try:
                with zf.open(info, "r") as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst, CHUNK)
            except OSError:
                if errors is None:
                    raise
                errors.append("/".join(parts))
                continue
            written += 1
            if progress is not None and (i % 50 == 0 or i == total - 1):
                if progress(int(100 * (i + 1) / total), "/".join(parts)) is False:
                    raise ArchiveError("cancelled")
    return written, skipped

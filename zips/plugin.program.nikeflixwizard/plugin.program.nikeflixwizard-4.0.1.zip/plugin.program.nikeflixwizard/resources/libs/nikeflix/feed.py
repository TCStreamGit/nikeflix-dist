# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""NikeFlix build feed (``builds.txt``, schema ``nikeflix.builds/1``; T23, plan §H).

Format: ``key="value"`` lines, ``#`` comments, blocks separated by blank lines. The first block may hold
``schema="nikeflix.builds/1"``. A block with ``id=`` is the wizard self-update entry; a block with ``name=`` is
a build. Every installable entry carries an exact ``url`` under the NikeFlix dist prefix, a ``sha256`` (64 hex)
and, for builds, ``kodi`` (e.g. ``21.3``)::

    schema="nikeflix.builds/1"

    id="plugin.program.nikeflixwizard"
    version="4.0.0"
    url="https://raw.githubusercontent.com/TCStreamGit/nikeflix-dist/main/zips/plugin.program.nikeflixwizard/plugin.program.nikeflixwizard-4.0.0.zip"
    sha256="<64 hex>"

    name="NikeFlix"
    edition="regular"
    version="4.0.0"
    url="https://raw.githubusercontent.com/TCStreamGit/nikeflix-dist/main/builds/nikeflixwizard-4.0.0.zip"
    sha256="<64 hex>"
    size="<bytes>"
    kodi="21.3"

Entries that fail validation are reported in ``rejected`` and are never installable (fail closed).
"""
import re

from resources.libs.nikeflix import distconfig
from resources.libs.nikeflix import versions

SCHEMA = "nikeflix.builds/1"
_LINE = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*"(.*)"\s*$')
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_KODI = re.compile(r"^(\d+)\.(\d+)$")


class FeedError(ValueError):
    pass


def _blocks(text):
    blocks, cur = [], {}
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line:
            if cur:
                blocks.append(cur)
                cur = {}
            continue
        if line.startswith("#"):
            continue
        m = _LINE.match(line)
        if not m:
            raise FeedError("malformed feed line: {0!r}".format(line[:80]))
        key, value = m.group(1).lower(), m.group(2)
        if key in cur:  # a repeated key starts a new block (tolerates missing blank lines)
            blocks.append(cur)
            cur = {}
        cur[key] = value
    if cur:
        blocks.append(cur)
    return blocks


def url_allowed(url, prefixes=None):
    prefixes = distconfig.ALLOWED_URL_PREFIXES if prefixes is None else prefixes
    if not isinstance(url, str) or not url.startswith("https://"):
        return False
    if any(c.isspace() for c in url) or "\\" in url or "/../" in url or url.endswith("/..") or "?" in url or "#" in url:
        return False
    return any(url.startswith(p) for p in prefixes)


def _check_common(entry, problems):
    if not versions.is_valid(entry.get("version", "")):
        problems.append("invalid version")
    if not url_allowed(entry.get("url", "")):
        problems.append("url not under the NikeFlix dist prefix")
    sha = entry.get("sha256", "")
    if not _SHA256.match(sha):
        problems.append("sha256 must be 64 lowercase hex characters")
    if "size" in entry:
        try:
            if int(entry["size"]) <= 0:
                raise ValueError
        except ValueError:
            problems.append("size must be a positive integer")


def validate_build(entry):
    problems = []
    if not entry.get("name", "").strip():
        problems.append("missing name")
    _check_common(entry, problems)
    if not _KODI.match(entry.get("kodi", "")):
        problems.append('kodi must look like "21.3"')
    if entry.get("edition", distconfig.EDITION) != distconfig.EDITION:
        problems.append("edition is not {0}".format(distconfig.EDITION))
    if not entry.get("url", "").endswith(".zip"):
        problems.append("url must name a .zip")
    return problems


def validate_wizard(entry, addon_id=None):
    addon_id = addon_id or distconfig.WIZARD_ID
    problems = []
    if entry.get("id") != addon_id:
        problems.append("id is not {0}".format(addon_id))
    _check_common(entry, problems)
    expected_tail = "/{0}-{1}.zip".format(addon_id, entry.get("version", ""))
    if not entry.get("url", "").endswith(expected_tail):
        problems.append("url must end with {0}".format(expected_tail))
    return problems


def parse(text):
    """Parse feed text into ``{"schema", "wizard", "builds", "rejected"}``. Raises FeedError if malformed."""
    if not isinstance(text, str):
        raise FeedError("feed must be text")
    blocks = _blocks(text)
    out = {"schema": None, "wizard": None, "builds": [], "rejected": []}
    for b in blocks:
        if set(b) == {"schema"}:
            out["schema"] = b["schema"]
            continue
        if "schema" in b:
            out["schema"] = b.pop("schema")
        if "id" in b:
            problems = validate_wizard(b)
            if problems:
                out["rejected"].append({"entry": b, "problems": problems})
            elif out["wizard"] is None:
                out["wizard"] = b
            else:
                out["rejected"].append({"entry": b, "problems": ["duplicate wizard entry"]})
        elif "name" in b:
            problems = validate_build(b)
            if problems:
                out["rejected"].append({"entry": b, "problems": problems})
            elif any(x["name"] == b["name"] for x in out["builds"]):
                out["rejected"].append({"entry": b, "problems": ["duplicate build name"]})
            else:
                out["builds"].append(b)
        else:
            out["rejected"].append({"entry": b, "problems": ["block has neither id nor name"]})
    if out["schema"] != SCHEMA:
        # A feed without the NikeFlix schema (e.g. the legacy OpenWizard format) is never installable.
        for b in out["builds"]:
            out["rejected"].append({"entry": b, "problems": ["feed schema is not {0}".format(SCHEMA)]})
        if out["wizard"]:
            out["rejected"].append({"entry": out["wizard"], "problems": ["feed schema is not {0}".format(SCHEMA)]})
        out["builds"], out["wizard"] = [], None
    return out


def find_build(parsed, name):
    for b in parsed["builds"]:
        if b["name"] == name:
            return b
    return None


def kodi_compat(build_kodi, device_kodi):
    """``ok`` (same major.minor), ``warn`` (same major, other minor) or ``block`` (other major / unknown)."""
    m = _KODI.match(str(build_kodi or ""))
    d = re.match(r"^(\d+)\.(\d+)", str(device_kodi or ""))
    if not m or not d:
        return "block"
    if m.group(1) != d.group(1):
        return "block"
    return "ok" if m.group(2) == d.group(2) else "warn"


def update_available(parsed, build_name, installed_version):
    """The newer build entry for the installed build, or None (semantic comparison, fail closed)."""
    b = find_build(parsed, build_name) if build_name else None
    if b and installed_version and versions.is_newer(b["version"], installed_version):
        return b
    return None


def wizard_update_available(parsed, installed_version):
    w = parsed.get("wizard")
    if w and versions.is_newer(w["version"], installed_version):
        return w
    return None

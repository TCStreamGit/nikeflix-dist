# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Wizard self-update from the feed's ``id=`` entry (T23; replaces the legacy ``zip=""`` dead path).

The primary update path is Kodi's own auto-update from ``repository.NikeFlix`` (the wizard is a
``nikeflix-auto`` M add-on). This path is the user-triggered fallback in the wizard menu: download the exact
URL, verify sha256 (and size when given), validate the archive (every member under
``plugin.program.nikeflixwizard/``; ``addon.xml`` id and version equal the feed), then swap the folder with two
renames. The caller runs ``UpdateLocalAddons`` afterwards. Never offered at startup.
"""
import os
import shutil
import uuid
import zipfile
import xml.etree.ElementTree as ET

from resources.libs.nikeflix import integrity
from resources.libs.nikeflix import versions


class UpdateError(Exception):
    pass


def apply(entry, addons_dir, installed_version, download, workdir):
    """``download(url, dest)`` fetches the archive. Returns the new version. Raises UpdateError on any failure."""
    addon_id = entry["id"]
    if not versions.is_newer(entry["version"], installed_version):
        raise UpdateError("not newer than the installed version")
    os.makedirs(workdir, exist_ok=True)
    zpath = os.path.join(workdir, "{0}-{1}.zip".format(addon_id, entry["version"]))
    work = os.path.join(addons_dir, ".nikeflix-update-" + uuid.uuid4().hex[:8])
    try:
        download(entry["url"], zpath)
        try:
            integrity.verify_file(zpath, entry["sha256"], size=entry.get("size"))
        except integrity.IntegrityError as exc:
            raise UpdateError(str(exc))
        try:
            members = integrity.inspect_archive(zpath, single_root=addon_id, max_unpacked=256 * 1024 * 1024)
            with zipfile.ZipFile(zpath) as zf:
                root = ET.fromstring(zf.read(addon_id + "/addon.xml"))
        except (integrity.ArchiveError, KeyError, ET.ParseError) as exc:
            raise UpdateError("archive rejected: {0}".format(exc))
        if root.get("id") != addon_id or root.get("version") != entry["version"]:
            raise UpdateError("addon.xml id/version does not match the feed")
        new_dir = os.path.join(work, "new")
        integrity.extract_members(zpath, members, new_dir)
        target = os.path.join(addons_dir, addon_id)
        old = os.path.join(work, "old")
        os.makedirs(old)
        moved = False
        if os.path.exists(target):
            os.rename(target, os.path.join(old, addon_id))
            moved = True
        try:
            os.rename(os.path.join(new_dir, addon_id), target)
        except OSError as exc:
            if moved:
                os.rename(os.path.join(old, addon_id), target)
            raise UpdateError("swap failed: {0}".format(exc))
        return entry["version"]
    finally:
        shutil.rmtree(work, ignore_errors=True)
        if os.path.exists(zpath):
            os.remove(zpath)

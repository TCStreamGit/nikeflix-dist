# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""Clean-install wipe planner and pre-install safety backup (T23; plan §A6 item 8, fresh-start runtime contract).

A NikeFlix build install removes **all** runtime state under the Kodi home, including
``userdata/profiles/**`` and every database, so each of the five profiles starts clean. Credentials are
re-provisioned per profile afterwards (plan §G4); Trakt is owned by the NikeFlix Trakt Hub.

Kept (never deleted):

* the running wizard (``addons/<wizard id>``) and its master-profile state (``userdata/addon_data/<wizard id>``);
* ``protected`` relative paths: files Kodi holds open, e.g. the live ``userdata/Database/Addons33.db`` (its
  content is replaced in place by the seed, see ``seed.py``) and the Kodi log files;
* opt-in keep options (all **default OFF**): favourites, sources, advancedsettings, playercorefactory.

Nothing outside the Kodi home is ever touched: every path is re-resolved (``realpath``) before deletion,
symlinks are unlinked rather than followed, and entries that resolve outside the home are refused.
"""
import datetime as _dt
import json
import os
import shutil

KEEP_OPTIONS = {
    "keepfavourites": "userdata/favourites.xml",
    "keepsources": "userdata/sources.xml",
    "keepadvanced": "userdata/advancedsettings.xml",
    "keepplayercore": "userdata/playercorefactory.xml",
}
DEFAULT_KEEP = {k: False for k in KEEP_OPTIONS}

# Files Kodi itself keeps open while the wizard runs.
LIVE_ADDONS_DB = "userdata/Database/Addons33.db"
LOG_NAMES = {"kodi.log", "kodi.old.log", "kodi.log.old"}

BACKUP_DIRNAME = "nikeflix-preinstall-backup"
BACKUP_EXCLUDE = ("addons/packages", "addons/temp", "temp", "cache", "userdata/Thumbnails",
                  "userdata/Database/Textures13.db")


class WipeError(Exception):
    pass


def _norm(path):
    return os.path.normcase(os.path.realpath(os.path.abspath(path)))


def is_inside(root, path):
    r, p = _norm(root), _norm(path)
    try:
        return os.path.commonpath([r, p]) == r
    except ValueError:
        return False


def _rel(home, path):
    return os.path.relpath(path, home).replace("\\", "/")


def default_protected():
    return {LIVE_ADDONS_DB, LIVE_ADDONS_DB + "-journal", LIVE_ADDONS_DB + "-wal", LIVE_ADDONS_DB + "-shm"}


def plan_wipe(home, wizard_id, keep=None, protected=None):
    """Return a plan dict: ``files``/``links``/``dirs`` to delete, ``kept`` and ``refused`` (rel paths)."""
    if not home or not os.path.isdir(home):
        raise WipeError("Kodi home does not exist")
    home = os.path.abspath(home)
    keep = dict(DEFAULT_KEEP, **(keep or {}))
    protected = set(default_protected() if protected is None else protected)
    keep_files = {KEEP_OPTIONS[k] for k, on in keep.items() if on and k in KEEP_OPTIONS}
    keep_dirs = {"addons/" + wizard_id, "userdata/addon_data/" + wizard_id}

    plan = {"home": home, "files": [], "links": [], "dirs": [], "kept": [], "refused": []}
    kept_dir_ancestors = set()

    def keep_ancestors(rel):
        parts = rel.split("/")
        for i in range(1, len(parts)):
            kept_dir_ancestors.add("/".join(parts[:i]))

    for dirpath, dirnames, filenames in os.walk(home, topdown=True, followlinks=False):
        rel_dir = _rel(home, dirpath)
        rel_dir = "" if rel_dir == "." else rel_dir
        keep_here = []
        for d in list(dirnames):
            full = os.path.join(dirpath, d)
            rel = (rel_dir + "/" + d) if rel_dir else d
            if rel in keep_dirs:
                plan["kept"].append(rel + "/")
                keep_ancestors(rel + "/x")
                keep_here.append(d)
            elif os.path.islink(full):
                plan["links"].append(full)
                keep_here.append(d)
            elif not is_inside(home, full):  # junction / reparse point leading outside the home
                plan["refused"].append(rel + "/")
                keep_ancestors(rel + "/x")
                keep_here.append(d)
        dirnames[:] = [d for d in dirnames if d not in keep_here]
        for f in filenames:
            full = os.path.join(dirpath, f)
            rel = (rel_dir + "/" + f) if rel_dir else f
            top_log = f.lower() in LOG_NAMES and rel_dir in ("", "temp")
            if rel in protected or rel in keep_files or top_log:
                plan["kept"].append(rel)
                keep_ancestors(rel)
            elif os.path.islink(full):
                plan["links"].append(full)
            elif not is_inside(home, full):
                plan["refused"].append(rel)
                keep_ancestors(rel)
            else:
                plan["files"].append(full)
        if rel_dir and rel_dir not in kept_dir_ancestors:
            plan["dirs"].append(dirpath)
    # dirs: deepest first; only those that are not ancestors of something kept
    plan["dirs"] = sorted((d for d in plan["dirs"] if _rel(home, d) not in kept_dir_ancestors),
                          key=lambda p: p.count(os.sep), reverse=True)
    return plan


def summarize(plan):
    home = plan["home"]
    rels = [_rel(home, p) for p in plan["files"]]
    return {
        "files": len(plan["files"]),
        "dirs": len(plan["dirs"]),
        "links": len(plan["links"]),
        "profiles_files": sum(1 for r in rels if r.startswith("userdata/profiles/")),
        "databases": sum(1 for r in rels if r.lower().endswith(".db")),
        "kept": sorted(plan["kept"]),
        "refused": sorted(plan["refused"]),
    }


def execute_wipe(plan, on_locked=None, progress=None):
    """Delete what ``plan`` lists. Every path is re-checked to be inside the home right before deletion.

    ``on_locked(path, exc)`` is called when a file cannot be removed (e.g. a database Kodi holds open); it may
    purge the content instead and return True. ``progress(percent, rel)`` may return False to cancel.
    Returns a report dict.
    """
    home = plan["home"]
    report = {"deleted": 0, "unlinked": 0, "dirs": 0, "failed": [], "purged": [], "cancelled": False}
    total = len(plan["files"]) + len(plan["links"]) or 1
    done = 0
    for path in plan["links"]:
        parent = os.path.dirname(path)
        if not is_inside(home, parent):
            report["failed"].append(_rel(home, path))
            continue
        try:
            if os.path.isdir(path) and not os.path.islink(path):
                os.rmdir(path)  # Windows junction: removes the link only
            else:
                os.unlink(path)
            report["unlinked"] += 1
        except OSError:
            report["failed"].append(_rel(home, path))
    for path in plan["files"]:
        done += 1
        rel = _rel(home, path)
        if not is_inside(home, path) or os.path.islink(path):
            report["failed"].append(rel)
            continue
        try:
            os.remove(path)
            report["deleted"] += 1
        except OSError as exc:
            if on_locked is not None and on_locked(path, exc):
                report["purged"].append(rel)
            else:
                report["failed"].append(rel)
        if progress is not None and done % 25 == 0:
            if progress(int(100 * done / total), rel) is False:
                report["cancelled"] = True
                return report
    for d in plan["dirs"]:
        if not is_inside(home, d) or _norm(d) == _norm(home):
            continue
        try:
            os.rmdir(d)  # only empty dirs; a dir that still holds a failed/locked file stays
            report["dirs"] += 1
        except OSError:
            pass
    return report


# ----------------------------------------------------------------------------------------------- backup
def default_backup_root(home):
    return os.path.join(os.path.dirname(os.path.abspath(home).rstrip("\\/")), BACKUP_DIRNAME)


def validate_backup_root(home, root):
    if not root:
        raise WipeError("no backup location")
    if is_inside(home, root):
        raise WipeError("the backup location must be outside the Kodi home (the wipe would delete it)")
    return os.path.abspath(root)


def make_backup(home, root, stamp=None, exclude=BACKUP_EXCLUDE, progress=None):
    """Copy the Kodi home to ``<root>/<stamp>/`` (minus caches). Returns a report; never deletes anything."""
    root = validate_backup_root(home, root)
    stamp = stamp or _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(root, stamp)
    if os.path.exists(dest):
        raise WipeError("backup folder already exists")
    os.makedirs(dest)
    report = {"path": dest, "files": 0, "bytes": 0, "errors": 0}
    excl = tuple(e.lower() for e in exclude)
    for dirpath, dirnames, filenames in os.walk(home, followlinks=False):
        rel_dir = _rel(home, dirpath)
        rel_dir = "" if rel_dir == "." else rel_dir
        dirnames[:] = [d for d in dirnames
                       if not os.path.islink(os.path.join(dirpath, d))
                       and ((rel_dir + "/" + d) if rel_dir else d).lower() not in excl]
        for f in filenames:
            rel = (rel_dir + "/" + f) if rel_dir else f
            src = os.path.join(dirpath, f)
            if rel.lower() in excl or os.path.islink(src):
                continue
            dst = os.path.join(dest, *rel.split("/"))
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                report["files"] += 1
                report["bytes"] += os.path.getsize(dst)
            except OSError:
                report["errors"] += 1
            if progress is not None and report["files"] % 200 == 0:
                if progress(report["files"], rel) is False:
                    raise WipeError("backup cancelled")
    with open(os.path.join(dest, "NIKEFLIX-BACKUP.json"), "w", encoding="utf-8") as fh:
        json.dump({"schema": "nikeflix.preinstall-backup/1", "created": stamp, "files": report["files"],
                   "bytes": report["bytes"], "errors": report["errors"],
                   "restore": "Stop Kodi, then copy this folder's contents back over the Kodi home."}, fh, indent=2)
    return report

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 NikeFlix (derived work of OpenWizard, Copyright (C) 2019 drinfernoo; see NOTICE.txt)
"""NikeFlix wizard core (plan OBJ-NFX-NG-01, task T23).

Every module in this package is pure Python 3.8 + standard library and never imports the Kodi modules
(xbmc*), so the install, wipe, seed, feed and Fen logic is unit-tested offline (tests/). Kodi glue lives in
``kodi_glue.py`` (the only module here that imports xbmc*, lazily).
"""

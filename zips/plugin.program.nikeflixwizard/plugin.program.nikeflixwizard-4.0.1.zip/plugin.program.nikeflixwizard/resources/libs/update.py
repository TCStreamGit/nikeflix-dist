################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcgui

import os
import re

from resources.libs.common.config import CONFIG


def wizard_update():
    """User-triggered wizard self-update from the feed's id= entry (semantic version compare, sha256-verified).

    Kodi's auto-update from repository.NikeFlix is the primary path; this is the in-wizard fallback. It is
    never offered at startup (T23).
    """
    from resources.libs import check
    from resources.libs.common import logging
    from resources.libs.nikeflix import kodi_glue
    from resources.libs.nikeflix import selfupdate

    dialog = xbmcgui.Dialog()
    progress_dialog = xbmcgui.DialogProgress()

    entry = check.wizard_entry_if_newer()
    if not entry:
        logging.log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]The wizard is up to date[/COLOR]'.format(CONFIG.COLOR2))
        return False
    if not dialog.yesno(CONFIG.ADDONTITLE,
                        'Update the wizard from v{0} to v{1}?'.format(CONFIG.ADDON_VERSION, entry['version']),
                        nolabel='Later', yeslabel='Update'):
        logging.log("[Wizard Update] v{0} postponed".format(entry['version']))
        return False
    progress_dialog.create(CONFIG.ADDONTITLE, 'Downloading wizard v{0}...'.format(entry['version']))
    try:
        selfupdate.apply(entry, CONFIG.ADDONS, CONFIG.ADDON_VERSION,
                         lambda url, dest: kodi_glue.http_download(url, dest),
                         os.path.join(CONFIG.PLUGIN_DATA, 'update'))
    except selfupdate.UpdateError as e:
        progress_dialog.close()
        logging.log("[Wizard Update] rejected: {0}".format(e), level=xbmc.LOGERROR)
        dialog.ok(CONFIG.ADDONTITLE, 'Wizard update rejected: {0}'.format(e))
        return False
    progress_dialog.close()
    xbmc.executebuiltin('UpdateLocalAddons')
    logging.log("[Wizard Update] updated to v{0}".format(entry['version']), level=xbmc.LOGINFO)
    logging.log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]Wizard updated to v{1}[/COLOR]'.format(CONFIG.COLOR2, entry['version']))
    return True


def addon_updates(do=None):
    setting = '"general.addonupdates"'
    if do == 'set':
        query = '{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{0}}}, "id":1}}'.format(setting)
        response = xbmc.executeJSONRPC(query)
        match = re.compile('{"value":(.+?)}').findall(response)
        if len(match) > 0:
            default = match[0]
        else:
            default = 0
        CONFIG.set_setting('default.addonupdate', str(default))
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(setting, '2')
        response = xbmc.executeJSONRPC(query)
    elif do == 'reset':
        # NikeFlix policy (T24): general.addonupdates=0 (install NikeFlix updates automatically), always.
        value = 0
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(setting, value)
        response = xbmc.executeJSONRPC(query)
        
        

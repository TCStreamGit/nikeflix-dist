# -*- coding: utf-8 -*-
import sys

from resources.lib.script import main

main(sys.argv[1:])

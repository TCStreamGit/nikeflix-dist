# service.nikeflix

This file is an early slice of plan tasks T31 and T32, done ahead of the Trakt broker because the 2026-10-18 review made the Fen privacy guard and fallback wrapper mandatory.

It contains:
- the `Kodi` adapter;
- the fail-closed profile guard (`profileguard.py`);
- Fen state hygiene (`fenstate.py`);
- the Umbrella → Fen 4 playback wrapper (`playback.py`);
- the T25 origin watchdog and pinned updater (`origin/`, settings category `origin`; design `docs/design/ORIGIN-WATCHDOG.md`). The updater is off by default and never touches Fen;
- the H3 profile-switch initiator (`session/quiesce.py`, 0.2.0 Option C, DEC-H3-C-STAGING; 0.2.1 playback preflight, DEC-H3-PLAYBACK-STAGING; 0.2.2-0.2.8 switch gate, DEC-H3-MODAL-STAGING; staged, not released): takes the skin's Switch-profile request (notification or `nikeflix.quiesce` marker), moves the skin's one `nikeflix_switch` LogOff alarm to a 45-s cap, waits for a settled profile, eight loop acknowledgements and TMDb Helper's `ServiceStarted`, then fires the same alarm; it never posts LogOff itself. During playback (or a playback still being torn down) it first cancels that alarm, stops the player, waits for its own player's stop callback plus a quiet second and for fresh acknowledgements, and only then arms the LogOff; otherwise it abandons the switch with a notice and the user stays in the profile. The alarm opens the skin's switch gate instead of logging off itself; before setting it off the service closes the power menu (only that) once everything else is ready and requires no modal dialog, abandoning at the cap if one stays open; afterwards it watches for the login screen and, if Kodi refused it behind a dialog, activates it once the dialog is gone (no second LogOff). 0.2.4: when Kodi stops the service mid-switch the main loop starts no background work (lab: origin/weather workers first polled after the stop request were still being joined at Kodi's 5-s kill, and the kill path hung). No settings; the notices are plain English like the existing one. On main (2026-11-11) the switch also waits while the deferred repository window (`repoupdate.py`) is younger than 30 s and then closes it, and the repository check makes no GUI call while a switch is pending or the login screen is up. Evidence: `docs/evidence/H3-QUIESCE-V5.md`, `docs/evidence/H3-OPTION-C-STAGING.md` (tag `archive/20261111/staging/h3-option-c`), `docs/evidence/H3-OPTION-C-LANDING.md`;
- the T51 session module (`session/`, settings category `session`, strings 32540–32549): `RunScript(service.nikeflix,action=intro_check)` grants the intro and the welcome toast once per Kodi process (Home-window PID marker). Evidence: `docs/evidence/T51-INTRO-ONCE.md`.

The Trakt broker (T31/T33) is still gated on T30/I2. Quiet Mode (T34), continuation (T36–T38), weather (T44) and shutdown (T53) arrive in their own reserved modules.

**Fen 4 is CX-LIC.** This add-on never contains, downloads into Git, or patches Fen code. It only reads Fen's per-profile settings database (read-only) and clears Kodi Home-window properties.

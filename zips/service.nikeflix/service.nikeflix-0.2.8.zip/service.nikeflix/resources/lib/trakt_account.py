# -*- coding: utf-8 -*-
"""Power-menu "Trakt Account" entry (plan section C; I9-R MD-18 keeps it in place of legacy "Trakt Setup").

The broker screen (Connect / Status / Switch / Disconnect) is T33 and needs the NikeFlix Trakt app (I2). Until
then this entry only explains that. It starts no Trakt flow and reads or writes no credential store."""
HEADING = 32550
MESSAGE = 32551


def show(kodi, dialog=None):
    kodi.log("trakt_account: broker screen not in this build (T31/T33 wait for I2); no Trakt flow started")
    if dialog is None:
        import xbmcaddon
        import xbmcgui
        addon = xbmcaddon.Addon("service.nikeflix")
        xbmcgui.Dialog().ok(addon.getLocalizedString(HEADING), addon.getLocalizedString(MESSAGE))
        return
    dialog(HEADING, MESSAGE)

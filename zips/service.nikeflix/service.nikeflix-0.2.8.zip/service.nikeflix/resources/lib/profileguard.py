# -*- coding: utf-8 -*-
"""Fail-closed profile-transition guard (2026-10-18 review, mandatory Fen privacy correction).

Kodi keeps one Home window for the whole process, so state written by one profile's add-ons survives a
switch to another profile. The guard:
  1. records the active profile (path + random token) and a monotonically increasing epoch;
  2. on every profile transition (service stop and start) bumps the epoch and invalidates Fen's cached
     routing/settings/results for BOTH the outgoing and incoming profiles;
  3. exposes `ready()`, which every fallback, scrobble or Fen-related operation must pass. `ready()` only
     succeeds when the recorded profile equals the active one, the guard state is `ready`, the caller's
     epoch is still current, and Fen's cached state validates against the ACTIVE profile.
Any doubt means "not ready": callers must abort rather than proceed.
"""
import uuid

from resources.lib import fenstate

P_PATH = "nikeflix.profile.path"
P_TOKEN = "nikeflix.profile.token"
P_EPOCH = "nikeflix.profile.epoch"
P_STATE = "nikeflix.guard.state"          # transition | ready
P_LAST = "nikeflix.profile.previous"      # previous profile path (for invalidation of its keys)


class Guard(object):
    def __init__(self, kodi):
        self.k = kodi

    # ---- profile path / epoch -------------------------------------------------------------------
    def active_path(self):
        return self.k.translate("special://profile/")

    def epoch(self):
        try:
            return int(self.k.get_prop(P_EPOCH) or "0")
        except ValueError:
            return 0

    def _bump(self):
        e = self.epoch() + 1
        self.k.set_prop(P_EPOCH, str(e))
        return e

    # ---- transitions ------------------------------------------------------------------------------
    def end_profile(self):
        """Called when this profile's service is stopping (profile switch or shutdown)."""
        leaving = self.k.get_prop(P_PATH) or self.active_path()
        self.k.set_prop(P_STATE, "transition")
        self._bump()
        self.k.set_prop(P_LAST, leaving)
        self.k.clear_prop(P_PATH)
        self.k.clear_prop(P_TOKEN)
        fenstate.invalidate(self.k, [fenstate.fen_dir(self.k, leaving)])

    def begin_profile(self, validate_timeout=15.0):
        """Called when the service starts in a profile. Returns True when the guard reached `ready`."""
        self.k.set_prop(P_STATE, "transition")
        self._bump()
        active = self.active_path()
        previous = self.k.get_prop(P_LAST)
        dirs = [fenstate.fen_dir(self.k, active)]
        if previous and previous != active:
            dirs.append(fenstate.fen_dir(self.k, previous))
        cleared = fenstate.invalidate(self.k, dirs)
        self.k.set_prop(P_PATH, active)
        self.k.set_prop(P_TOKEN, uuid.uuid4().hex)
        deadline = self.k.now() + validate_timeout
        while True:
            ok, reason, _ = fenstate.validate(self.k, active)
            if ok:
                self.k.set_prop(P_STATE, "ready")
                self.k.log("profile guard ready (cleared %d cached keys)" % cleared)
                return True
            # Something (e.g. a stale writer) re-populated Fen state from another profile: clear again.
            fenstate.invalidate(self.k, dirs)
            if self.k.now() >= deadline or self.k.wait(0.5):
                self.k.log("profile guard NOT ready: %s" % reason, "warning")
                return False

    # ---- checks ---------------------------------------------------------------------------------
    def ready(self, expected_epoch=None, expected_path=None):
        """(ok, reason). Fail closed on any doubt."""
        if self.k.get_prop(P_STATE) != "ready":
            return False, "guard not ready (profile transition in progress)"
        active = self.active_path()
        if self.k.get_prop(P_PATH) != active:
            return False, "recorded profile differs from the active profile"
        if expected_path is not None and expected_path != active:
            return False, "request was made in a different profile"
        if expected_epoch is not None and expected_epoch != self.epoch():
            return False, "profile changed since the request started"
        ok, reason, _ = fenstate.validate(self.k, active)
        if not ok:
            return False, reason
        return True, "ok"

    def wait_ready(self, expected_epoch, expected_path, timeout):
        """Wait up to `timeout` s for the guard; never waits across an epoch change."""
        deadline = self.k.now() + timeout
        while True:
            ok, reason = self.ready(expected_epoch, expected_path)
            if ok:
                return True, reason
            if expected_epoch != self.epoch() or self.k.now() >= deadline or self.k.wait(0.5):
                return False, reason

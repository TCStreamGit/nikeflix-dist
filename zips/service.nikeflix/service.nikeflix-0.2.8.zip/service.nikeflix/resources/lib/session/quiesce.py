# -*- coding: utf-8 -*-
"""H3 profile-switch initiator (Option C, DEC-H3-C-STAGING).

Installed as service.nikeflix/resources/lib/session/quiesce.py.

ONE LogOff path: the skin's "Switch profile" does three things, in this order -
    AlarmClock(nikeflix_switch,SetProperty(nikeflix.gate,go,home),00:00:40,silent)  # always switches, even without this service
    SetProperty(nikeflix.quiesce,switch:$INFO[System.Time(hh:mm:ss)],home)  # parks the poll loops at once, by itself
    NotifyAll(service.nikeflix,profile_switch)                               # wakes this service sooner
(while something plays - Player.HasMedia at the click - the alarm's command is a notification instead: without
this service a click during playback only tells the user it did not switch; see PLAYBACK. The alarm's command opens
the skin's switch gate, which runs System.LogOff through a 0-s alarm of the same name; see MODAL)
(alarm first, so a marker this service sees always has its alarm - lab v5 r2: with the marker first the service
twice looked in between and found no alarm yet; MARKER_GRACE_S also covers that)
Kodi's alarm clock is the only thing that runs System.LogOff. This service never posts LogOff itself; it can only
move that one named alarm while it is still pending (AlarmClock with the same name replaces it):
  1. take over: move the alarm to SAFETY_CAP_S (bounded even if this service then dies);
  2. quiesce: replace the button marker by "<deadline>:<token>", which the loops acknowledge (variant B only);
  3. wait until READY - profile at least SETTLE_S old, every enabled poll loop acknowledged the token (proof it
     reached its gate, i.e. finished the pass it was in and stands still), and TMDb Helper reports
     TMDbHelper.ServiceStarted - or until the cap;
  4. renew the request for LOGOFF_HOLD_S and move the alarm to "now".
A request is taken from the notification OR from the button marker, so a click made before this service was
running (it starts a few seconds after a profile loads; lab v3 soak switch 17) is still honoured - but only while
the click's alarm is still pending.
Fallbacks: service disabled / crashed / never picks the request up -> the skin's alarm fires after 40 s, with the
loops still parked by the button marker (lab v4 r2 switch 3: an unquiesced fallback LogOff at profile age 70 s
hung Kodi in its kill path) and never sooner than the settle time; service fails while waiting -> the alarm fires
at the cap; duplicate clicks -> the same alarm is re-armed, this service re-asserts its planned time and its
request; the alarm only ever fires once, so there is no double LogOff. The service never re-arms an alarm that is
gone or less than 1 s from firing.

Lab finding behind the settle gate: switching while service add-ons are still starting can hang Kodi 21.3 for good
in its 5-s kill path (stock NikeFlix stack, 4/4; exact blocking call unidentified).

PLAYBACK (DEC-H3-PLAYBACK-STAGING): a LogOff that overlaps a player teardown hung Kodi 21.3 (staged 2 of 5, stock
1 of 1; exact blocking call unidentified). When something plays, or a playback is still being torn down, the
switch first stops it, with NO LogOff alarm pending:
  a. cancel the switch alarm (so neither the skin's 40-s fallback nor the cap can fire during the stop, even if
     this service dies now - the switch is then simply not made and the request expires);
  b. PlayerControl(Stop) (again at most once a second while the player is still opening);
  c. wait for proof that the player is gone: this service's own xbmc.Player received onPlayBackStopped/Ended/Error
     after the switch began - Kodi 21.3 announces that to Python only after PlaybackCleanup on the GUI thread
     (player reset, playback window closed) and queues the callbacks of every Python player in the same pass
     (Application.cpp GUI_MSG_PLAYBACK_STOPPED, XBPython::OnPlayBackStopped) - then no media and no playback window
     for STOP_STABLE_S without a break;
  d. only then issue a NEW token: each gated loop's acknowledgement of it is written on the thread that runs its
     player callbacks, right after a waitForAbort, which runs that thread's queued callbacks (Monitor.cpp
     MakePendingCalls), so acknowledgements given after (c) prove those callbacks have run;
  e. the normal READY wait, and the LogOff alarm is armed at "now" only when everything is in.
Not proven by STOP_TIMEOUT_S (still playing, or no stop callback), or not READY by the cap, or playback starting
again after this service stopped it: the switch is abandoned - alarm cancelled, marker and request cleared, the
user stays in this profile and gets a plain notification.

MODAL (DEC-H3-MODAL-STAGING): Kodi 21.3's System.LogOff loads the master profile and then activates the login
screen once; the window manager refuses that while a modal dialog is open (GUIWindowManager.cpp, HasModalDialog(true)
= System.HasActiveModalDialog), leaving the switch stranded on Home with the master profile loaded (lab: the power
menu reopened during the deferral; stock System.LogOff the same). Every LogOff of the switch therefore passes the
skin's gate (Custom_1198 closes the power menu - only that - and Custom_1199 then arms the 0-s LogOff alarm only
with no modal dialog, nothing playing and no login screen up, else clears the request and tells the user), also
when this service is disabled, late or dead. This service, before setting the gate off, closes the power menu only
once everything else is ready and requires no modal dialog (judged on the next pass, never assumed); a dialog still
open at the cap abandons the switch. No other dialog is ever closed. Known limit: a dialog other than the power
menu that opens between stage 2's check and the LogOff (Kodi's alarm thread polls every 100 ms) or during the
LogOff itself still makes Kodi refuse the login screen - Kodi 21.3 has no atomic check-and-log-off. If Kodi
refuses the login screen, leaving the master profile
this service keeps running and supervise() activates it once the dialog is gone (no second LogOff); leaving any
other profile Kodi stops this service and reloads the skin in the master profile - lab recoveries from there
froze or crashed Kodi, so none is attempted. The power menu also closes itself while the gate says "logoff".
"""
import math
import time
import uuid

PROPERTY = "nikeflix.quiesce"
ACK_PREFIX = "nikeflix.quiesce.ack."
BUTTON = "switch"                  # PROPERTY = "switch:<hh:mm:ss>": the skin's click (local time, 12- or 24-hour)
ALARM = "nikeflix_switch"          # lower case: Kodi looks alarms up in lower case
SENDER = "service.nikeflix"
METHODS = {"Other.profile_switch": False, "Other.profile_switch_dry_run": True}
MARKER_GRACE_S = 2.0               # a marker without its alarm is looked at again for this long
SKIN_FALLBACK_S = 40               # what the skin arms: longer than SETTLE_S plus margin (v3 soak hang)
SAFETY_CAP_S = 45.0                # upper bound for the whole switch once this service owns it
SETTLE_S = 30.0
MIN_WAIT_S = 0.3
REQUEST_MARGIN_S = 30.0            # the request outlives the cap by the time Kodi needs to stop the services, so a
                                   # service that dies after takeover still leaves the loops parked through the
                                   # cap's LogOff (lab audit); it then expires on its own
LOGOFF_HOLD_S = 30.0               # renewed at the moment of firing: covers Kodi stopping the services (lab audit:
                                   # on the cap path only 8 s of the first request were left); the login screen's
                                   # marker replaces it, and if LogOff never comes it still ends on its own
STOP_TIMEOUT_S = 15.0              # PLAYBACK: the stop must be proven within this (lab: under 2 s), else abandon
STOP_STABLE_S = 1.0                # PLAYBACK: after the stop callback, no media and no playback window this long
STOP_RETRY_S = 1.0                 # PLAYBACK: PlayerControl(Stop) again while the player is still there (opening)
PLAYING = "Player.HasMedia | Window.IsActive(fullscreenvideo) | Window.IsActive(visualisation)"
NOTICE = "Profile not switched - stop playback and try again"   # the skin's alarm and an abandoned switch
# MODAL (DEC-H3-MODAL-STAGING): the one alarm never runs System.LogOff itself; it opens the skin's switch gate
GATE = "nikeflix.gate"
GATE_GO = "SetProperty(%s,go,home)" % GATE
POWER_MENU = "shutdownmenu"        # the only dialog this switch ever closes (the menu the user clicked in)
MODAL = "System.HasActiveModalDialog"   # exactly what refuses the login screen (HasModalDialog(true))
MODAL_NOTICE = "Profile not switched - close the open window and try again"
SUPERVISE_S = 20.0                 # after firing: the login screen's marker is expected well within this
STRAND_WAIT_S = 600.0              # a refused login screen: wait this long for the blocking dialog to go
QUIESCE = True                     # False: variant A (settle gate only, no service patches)
LAB_FAULTS = False                 # True only in lab overlays (build_candidate.py); never in a release
TMDB = "plugin.video.themoviedb.helper"
# (add-on id, ack slot): every gated loop. An acknowledgement is the only proof that a loop has finished starting
# up and reached its gate - lab v5: the last loop first reached its gate up to 35.8 s after Kodi started the
# services (artwork.beef; a4kSubtitles 33.8 s), later than SETTLE_S, so the settle time alone does not prove it.
SLOTS = (
    ("script.skin.helper.service", "script.skin.helper.service"),
    ("script.skin.helper.backgrounds", "script.skin.helper.backgrounds"),
    (TMDB, "plugin.video.themoviedb.helper.ServiceMonitor"),
    (TMDB, "plugin.video.themoviedb.helper.ImagesMonitor"),
    (TMDB, "plugin.video.themoviedb.helper.CronJobMonitor"),   # lab v5 soak switch 27 (docs/evidence/H3-QUIESCE-V5.md)
    ("plugin.video.youtube", "plugin.video.youtube"),
    ("script.artwork.beef", "script.artwork.beef"),
    ("service.subtitles.a4ksubtitles", "service.subtitles.a4ksubtitles"),
    ("plugin.video.umbrella", "plugin.video.umbrella"),   # account-sync loop (H3-UMBRELLA-PAUSE: killed ~1 in 6 before)
)


def is_deadline(value):
    """A "<epoch>:<token>" request (this service's own), as opposed to a "switch:" / "login:" marker."""
    head, sep, token = value.partition(":")
    try:
        float(head)
    except ValueError:
        return False
    return bool(sep and token)


def hms(seconds):
    s = max(0, int(math.ceil(seconds)))
    return "%02d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60)


def alarm_movable(kodi):
    """The switch alarm exists and is not about to fire: moving it cannot create a second LogOff."""
    return kodi.cond("System.HasAlarm(%s)" % ALARM) and not kodi.cond("System.AlarmLessOrEqual(%s,1)" % ALARM)


def move_alarm(kodi, seconds):
    if not alarm_movable(kodi):
        return False
    kodi.builtin("AlarmClock(%s,%s,%s,silent)" % (ALARM, GATE_GO, hms(seconds)))
    return True


def lab_fault(kodi, name):
    return LAB_FAULTS and kodi.get_prop("nikeflix.lab.fault") == name


def cancel_alarm(kodi):
    """PLAYBACK: no LogOff may be pending while a player stops (also covers a duplicate click's new alarm)."""
    if kodi.cond("System.HasAlarm(%s)" % ALARM):
        kodi.builtin("CancelAlarm(%s,true)" % ALARM)


class PlaybackWatch(object):
    """PLAYBACK: service.nikeflix's own xbmc.Player, created on its main thread, so Kodi runs these callbacks while
    that thread waits. They only record the event; they make no Kodi call."""

    def __init__(self, player_class=None):
        if player_class is None:
            import xbmc
            player_class = xbmc.Player
        holder = self

        class _Player(player_class):
            def onPlayBackStarted(self):
                holder.event("start")

            def onAVStarted(self):
                holder.event("start")

            def onPlayBackStopped(self):
                holder.event("end")

            def onPlayBackEnded(self):
                holder.event("end")

            def onPlayBackError(self):
                holder.event("end")

        self.ends = 0
        self.last = None
        self.player = _Player()

    def event(self, kind):
        self.last = kind
        if kind == "end":
            self.ends += 1

    def busy(self, kodi):
        """Something plays, or a playback started and Kodi has not yet announced its stop (still tearing down)."""
        return self.last == "start" or kodi.cond(PLAYING)


def stop_playback(kodi, watch, clock, duplicate=None):
    """PLAYBACK steps a-c, with no LogOff alarm pending throughout. Returns (True, seconds) once the player is proven
    gone, (False, "aborted") when Kodi stops this service, else (False, why) at STOP_TIMEOUT_S."""
    t0 = clock()
    ends = watch.ends
    sent = None
    calm_since = None
    while True:
        if duplicate is not None:
            duplicate()                       # another click meanwhile: nothing to add, its alarm goes next line
        cancel_alarm(kodi)
        if lab_fault(kodi, "crash_while_stopping"):
            raise RuntimeError("lab fault: crash while stopping playback")
        now = clock()
        playing = kodi.cond(PLAYING)
        if playing:
            calm_since = None
            if (sent is None or now - sent >= STOP_RETRY_S) and not lab_fault(kodi, "stop_ignored"):
                kodi.builtin("PlayerControl(Stop)")
                sent = now
        elif watch.ends > ends and watch.last == "end":
            if calm_since is None:
                calm_since = now
            if now - calm_since >= STOP_STABLE_S:
                return True, round(now - t0, 2)
        else:
            calm_since = None
        if now - t0 >= STOP_TIMEOUT_S:
            if not playing:
                watch.last = None             # judged once: a lost stop callback must not block every later switch
            return False, "still playing" if playing else "no stop callback"
        if kodi.wait(0.25):
            return False, "aborted"


def held(hold):
    """REPOSITORY: the caller's reason to hold the switch back (service.nikeflix: its repository-check window, whose
    Kodi job deadlocks against a profile load), else None. A failing check never holds a switch; the cap still
    bounds the wait."""
    if hold is None:
        return None
    try:
        return hold()
    except Exception:
        return None


def clear_acks(kodi):
    for _addon, slot in SLOTS:
        kodi.clear_prop(ACK_PREFIX + slot)


def abandon(kodi, report, why, notice=NOTICE):
    """PLAYBACK / MODAL: no switch. Nothing stays pending or parked; the user stays in this profile and is told."""
    kodi.builtin("CancelAlarm(%s,true)" % ALARM)
    value = kodi.get_prop(PROPERTY)
    if value.startswith(BUTTON + ":") or is_deadline(value):
        kodi.clear_prop(PROPERTY)
    kodi.clear_prop(GATE)
    clear_acks(kodi)
    kodi.builtin("Notification(NikeFlix,%s,%d)" % (notice, 8000))
    report.update({"abandoned": why, "fired": False})
    kodi.log("profile switch abandoned (%s) - staying in this profile" % why)
    return report


def modal_open(kodi):
    """MODAL: True while a modal dialog would make Kodi refuse the login screen. Only the power menu is closed (the
    switch was clicked in it, or it was reopened meanwhile); the close is judged again on the next pass, never
    assumed. Any other dialog - a keyboard, settings, a script's question - is left to the user."""
    if kodi.cond("Window.IsActive(%s)" % POWER_MENU):
        kodi.builtin("Dialog.Close(%s,true)" % POWER_MENU)
        return True
    return kodi.cond(MODAL)


def supervise(kodi, clock):
    """MODAL: after the gate was set off. The login screen's marker (LoginScreen.xml onload) means done; the gate
    clearing the request means it cancelled the switch. Otherwise Kodi logged off but refused the login screen
    behind a modal dialog (stock Kodi 21.3: CProfileManager::LogOff activates it once): once that dialog is gone -
    the power menu is closed, anything else is waited for - activate the login screen, the one step LogOff skipped.
    Home properties only until SUPERVISE_S (LogOff may still hold the GUI); GUI conditions only after that."""
    t0 = clock()
    while clock() - t0 < SUPERVISE_S:
        value = kodi.get_prop(PROPERTY)
        if value.startswith("login"):
            return "login screen"
        if not value and not kodi.get_prop(GATE):
            clear_acks(kodi)
            return "cancelled at the gate"
        if kodi.wait(0.25):
            return "aborted"
    if kodi.cond("Window.IsActive(loginscreen)"):
        return "login screen"
    kodi.log("profile switch: Kodi logged off but a dialog blocked the login screen - completing it once it is gone")
    while clock() - t0 < STRAND_WAIT_S:
        if not modal_open(kodi):
            kodi.builtin("ActivateWindow(loginscreen)")
            for _ in range(20):
                if kodi.wait(0.25):
                    return "aborted"
                if kodi.get_prop(PROPERTY).startswith("login"):
                    return "login screen completed after a blocking dialog"
        if kodi.wait(0.5):
            return "aborted"
    return "stranded behind a dialog"


def profile_switch(kodi, dry_run=False, clock=time.time, started_at=None, quiesce=None, duplicate=None,
                   playback=None, hold=None):
    """Returns a small report (also logged). `kodi` is service.nikeflix's Kodi adapter; `started_at` is when
    service.nikeflix started in this profile; `duplicate()` returns True when another click arrived meanwhile;
    `playback` is the PlaybackWatch (None: no playback handling); `hold()` returns a reason to wait (see held)."""
    quiesce = QUIESCE if quiesce is None else quiesce
    t0 = t_click = clock()
    watch = None if dry_run else playback
    if watch is not None and watch.busy(kodi):
        if not alarm_movable(kodi):           # PLAYBACK: never re-arm a LogOff alarm while something plays
            kodi.log("profile switch: no movable switch alarm (fallback already firing or no button) - not taking over")
            return {"took_over": False}
    elif not dry_run and not move_alarm(kodi, SAFETY_CAP_S):
        kodi.log("profile switch: no movable switch alarm (fallback already firing or no button) - not taking over")
        return {"took_over": False}
    if lab_fault(kodi, "crash_after_takeover"):
        raise RuntimeError("lab fault: crash after takeover")
    token = uuid.uuid4().hex[:12]
    request = "%.3f:%s" % (t0 + SAFETY_CAP_S + REQUEST_MARGIN_S, token)
    expected = []
    if quiesce:
        kodi.set_prop(PROPERTY, request)
        expected = [slot for addon, slot in SLOTS if kodi.cond("System.AddonIsEnabled(%s)" % addon)]
    tmdb_on = kodi.cond("System.AddonIsEnabled(%s)" % TMDB)
    notified = False
    reason = "cap"
    acked = []
    why_held = None
    blocking = False
    stopped = None                            # PLAYBACK: seconds the proven stop took, once this switch stopped one
    while True:
        if lab_fault(kodi, "crash_while_waiting"):   # after takeover and request: the service dies mid-switch
            raise RuntimeError("lab fault: crash while waiting")
        if watch is not None and watch.busy(kodi):
            if stopped is not None:
                return abandon(kodi, {"reason": "playback", "playback_stop_s": stopped}, "playback started again")
            cancel_alarm(kodi)
            kodi.builtin("Notification(NikeFlix,Stopping playback to switch profile,%d)" % 4000)
            ok, detail = stop_playback(kodi, watch, clock, duplicate)
            if detail == "aborted":
                return {"aborted": True}
            if not ok:
                return abandon(kodi, {"reason": "playback"}, detail)
            stopped = detail
            t0 = clock()                      # step d: a new token, issued only now
            token = uuid.uuid4().hex[:12]
            request = "%.3f:%s" % (t0 + SAFETY_CAP_S + REQUEST_MARGIN_S, token)
            if quiesce:
                kodi.set_prop(PROPERTY, request)
            continue
        now = clock()
        waited = now - t0
        age_ok = started_at is None or now - started_at >= SETTLE_S
        acked = [s for s in expected if kodi.get_prop(ACK_PREFIX + s) == token]
        if stopped is not None and lab_fault(kodi, "stuck_callback"):   # a loop whose callback never returns
            acked = [s for s in acked if s != "plugin.video.themoviedb.helper.ImagesMonitor"]
        tmdb_ok = not tmdb_on or kodi.get_prop("TMDbHelper.ServiceStarted") == "True"
        why_held = None if dry_run else held(hold)   # a dry run never closes the repository window
        ready = age_ok and len(acked) == len(expected) and tmdb_ok and waited >= MIN_WAIT_S and not why_held
        at_cap = waited >= SAFETY_CAP_S - 3.0
        # MODAL: only once the switch would fire - so the power menu stays usable while the switch is pending
        blocking = not dry_run and (ready or at_cap) and modal_open(kodi)
        if ready and not blocking:
            reason = "ready"
            break
        if at_cap and (not blocking or waited >= SAFETY_CAP_S - 1.0):
            break
        if not notified and waited >= 1.0:
            kodi.builtin("Notification(NikeFlix,Switching profile when start-up has finished,%d)" % 4000)
            notified = True
        dup = duplicate is not None and duplicate()
        if quiesce and kodi.get_prop(PROPERTY).startswith(BUTTON + ":"):
            dup = True                            # another click's marker replaced our request (even same second)
        if dup and not dry_run:                   # another click re-armed the 40-s alarm
            if stopped is None:
                move_alarm(kodi, SAFETY_CAP_S - waited)
            if quiesce:
                kodi.set_prop(PROPERTY, request)  # same token back: acknowledgements already given stay valid
        if stopped is not None:
            cancel_alarm(kodi)                    # PLAYBACK: the LogOff alarm is armed only when everything is in
        if kodi.wait(0.25):
            return {"aborted": True}
    report = {"reason": reason, "expected": len(expected), "acked": len(acked), "waited_s": round(clock() - t0, 2),
              "missing": sorted(set(expected) - set(acked)), "dry_run": bool(dry_run),
              "age_s": None if started_at is None else round(t_click - started_at, 1), "quiesce": bool(quiesce),
              "playback_stop_s": stopped, "held": why_held}
    if dry_run:
        kodi.log("profile switch (dry run): %s after %.2fs, %d/%d acknowledged" % (
            reason, report["waited_s"], report["acked"], report["expected"]))
        return report
    if blocking:
        return abandon(kodi, report, "a dialog stayed open", MODAL_NOTICE)
    if stopped is not None and reason != "ready":
        return abandon(kodi, report, "not ready by the cap after stopping playback (missing %s)" % (
            ", ".join(report["missing"]) or "start-up"))
    if kodi.get_prop(PROPERTY).startswith("login"):
        report["already_logged_off"] = True
        kodi.log("profile switch: the login screen is already up - nothing to do")
        return report
    if quiesce:
        kodi.set_prop(PROPERTY, "%.3f:%s" % (clock() + LOGOFF_HOLD_S, token))
    if stopped is not None:
        kodi.builtin("AlarmClock(%s,%s,%s,silent)" % (ALARM, GATE_GO, hms(0)))   # the one alarm, set off now
        report["fired"] = True
    else:
        report["fired"] = move_alarm(kodi, 0)
    kodi.log("profile switch: %s after %.2fs (profile age %ss), %d/%d acknowledged%s%s%s - %s" % (
        reason, report["waited_s"], report["age_s"], report["acked"], report["expected"],
        (" (missing %s)" % ", ".join(report["missing"])) if report["missing"] else "",
        (" (held: %s)" % why_held) if why_held else "",
        (", playback stopped in %.2fs" % stopped) if stopped is not None else "",
        "switching now" if report["fired"] else "alarm already firing"))
    if report["fired"]:
        report["outcome"] = supervise(kodi, clock)
        kodi.log("profile switch outcome: %s" % report["outcome"])
    return report


def clear_stale(kodi):
    """service.nikeflix start: a request left over from the previous profile must not pause the new one. Only this
    service's own deadline requests are cleared: a "switch:" marker may be a click made before this service started
    (judged by SwitchRequests.serve), and a "login:" marker belongs to the login screen; both expire on their own."""
    clear_acks(kodi)
    if is_deadline(kodi.get_prop(PROPERTY)):
        kodi.clear_prop(PROPERTY)
        kodi.log("cleared a leftover profile-switch request")


class SwitchRequests(object):
    """Receives NotifyAll(service.nikeflix,profile_switch[_dry_run]) on a Monitor owned by service.nikeflix's main
    thread (callbacks are delivered while that thread waits), notices the skin's button marker, and runs the
    sequence from the main loop. Its PlaybackWatch is created on the same thread."""

    COOLDOWN_S = 10.0

    def __init__(self, monitor_class=None, started_at=None, clock=time.time, player_class=None):
        if monitor_class is None:
            import xbmc
            monitor_class = xbmc.Monitor
        holder = self

        class _Monitor(monitor_class):
            def onNotification(self, sender, method, data):
                if sender == SENDER and method in METHODS:
                    holder.request = method

        self.request = None
        self.started_at = started_at
        self.clock = clock
        self.last_done = None
        self.marker = None            # the last button marker seen, so each click is judged once
        self.marker_since = None      # while not None: that marker is still to be judged
        self.monitor = _Monitor()
        try:
            self.playback = PlaybackWatch(player_class)
        except Exception:             # no player events: the skin still never arms LogOff during playback
            self.playback = None

    def _new_marker(self, kodi):
        value = kodi.get_prop(PROPERTY)
        if value.startswith(BUTTON + ":") and value != self.marker:
            self.marker, self.marker_since = value, self.clock()
            return True
        return False

    def _take_duplicate(self, kodi):
        dup = bool(self.request)
        self.request = None
        if self._new_marker(kodi):
            self.marker_since = None
            dup = True
        return dup

    def serve(self, kodi, hold=None):
        method, self.request = self.request, None
        self._new_marker(kodi)
        if self.marker_since is not None:
            if method:
                self.marker_since = None              # the notification brought the same click
            elif alarm_movable(kodi):
                self.marker_since = None
                method = "Other.profile_switch"   # a click made before this service was running (or a lost notice)
                kodi.log("profile switch: request taken from the button marker")
            elif self.clock() - self.marker_since > MARKER_GRACE_S:
                self.marker_since = None
                kodi.log("profile switch: button marker without a pending alarm - left to expire")
        if not method:
            return None
        if self.last_done is not None and self.clock() - self.last_done < self.COOLDOWN_S:
            kodi.log("profile switch: duplicate request ignored")
            return None
        report = None
        try:
            report = profile_switch(kodi, dry_run=METHODS[method], clock=self.clock, started_at=self.started_at,
                                    duplicate=lambda: self._take_duplicate(kodi), playback=self.playback, hold=hold)
            return report
        finally:   # an abandoned switch is no reason to ignore the user's next click
            self.last_done = None if (report or {}).get("abandoned") else self.clock()

# -*- coding: utf-8 -*-
"""Process-session marker: intro once per Kodi process (plan task T51; module reserved by T31).

Kodi keeps one Home window (10000) for the whole process, and its properties survive profile switches
(T05 finding 3), while a new Kodi process starts with none. The marker is therefore a Home-window property
holding the Kodi PID (`os.getpid()`: add-on Python runs inside the Kodi process) plus the time the session
was first seen. A PID mismatch is treated as a new process, so a stale marker can never suppress the intro.

The skin asks through `RunScript(service.nikeflix,action=intro_check)` from `Startup.xml` on every profile
load. RunScript takes 1-4 s during a profile load, so on the first load of a process (no `nikeflix.session.pid`
yet) the skin arms the mask itself and this check confirms it. `intro_check()` sets or clears two Home
properties that the skin reads:

  NikeFlix.Intro.Play    "1"  -> the start-up mask (Custom_1103) opens and plays the intro once
  NikeFlix.Welcome.Show  "1"  -> the welcome toast is shown when that mask closes

Rules: the intro plays on the first profile load of a Kodi process only (unless the per-profile setting
`session.intro.once` is off, which restores the intro on every profile load); the welcome toast is shown for
the first profile of the process only, whatever the intro setting.
"""
import os
import uuid

ADDON_ID = "service.nikeflix"

P_PID = "nikeflix.session.pid"            # Kodi process id that owns the marker
P_START = "nikeflix.session.start"        # epoch seconds when this process session was first seen
P_INTRO = "nikeflix.session.intro"        # claim token once the intro was granted in this process
P_WELCOME = "nikeflix.session.welcome"    # claim token once the welcome toast was granted

SKIN_INTRO = "NikeFlix.Intro.Play"
SKIN_WELCOME = "NikeFlix.Welcome.Show"

CLAIM_SETTLE_S = 0.05                     # re-read delay that resolves two concurrent intro_check calls


def _setting(key):
    """Raw string value of a service.nikeflix setting ('' outside Kodi or if unknown)."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon(ADDON_ID).getSetting(key) or ""
    except Exception:
        return ""


class Session(object):
    def __init__(self, kodi, getpid=os.getpid):
        self.k = kodi
        self._getpid = getpid

    # ---- marker -----------------------------------------------------------------------------------
    def pid(self):
        return str(self._getpid())

    def ensure(self):
        """Bind the marker to this Kodi process. Returns True when this call started a new session."""
        pid = self.pid()
        if self.k.get_prop(P_PID) == pid:
            return False
        # No marker (fresh process) or a marker from another PID: start a new session; nothing granted yet.
        self.k.set_prop(P_PID, pid)
        self.k.set_prop(P_START, str(int(self.k.now())))
        self.k.clear_prop(P_INTRO)
        self.k.clear_prop(P_WELCOME)
        return True

    def started_at(self):
        try:
            return int(self.k.get_prop(P_START) or "0")
        except ValueError:
            return 0

    def _claim(self, key):
        """Grant `key` once per process. Two racing callers both write a token, wait briefly and re-read;
        only the caller whose token survived wins. An abort during the wait denies the claim."""
        self.ensure()
        if self.k.get_prop(key):
            return False
        token = "%s:%s" % (self.pid(), uuid.uuid4().hex[:12])
        self.k.set_prop(key, token)
        if self.k.wait(CLAIM_SETTLE_S):
            return False
        return self.k.get_prop(key) == token

    # ---- public API -------------------------------------------------------------------------------
    def should_play_intro(self):
        """True only for the first call in this Kodi process; the intro is then marked as played."""
        return self._claim(P_INTRO)

    def should_show_welcome(self):
        """True only for the first profile of this Kodi process."""
        return self._claim(P_WELCOME)


def intro_check(kodi, once=None, getpid=os.getpid, setting=_setting):
    """Skin entry point. Sets/clears the skin's Home properties and returns (play_intro, show_welcome)."""
    if once is None:
        once = setting("session.intro.once").lower() != "false"
    session = Session(kodi, getpid)
    new = session.ensure()
    if kodi.aborted():
        kodi.clear_prop(SKIN_INTRO)
        kodi.clear_prop(SKIN_WELCOME)
        return False, False
    granted = session.should_play_intro()
    play = granted or not once
    welcome = session.should_show_welcome()
    # Welcome first: the mask reads it when it closes.
    if welcome:
        kodi.set_prop(SKIN_WELCOME, "1")
    else:
        kodi.clear_prop(SKIN_WELCOME)
    if play:
        # The skin may already have armed ("1") or started ("started") the mask through its fast path; re-writing
        # "1" would replay the clip on the next re-init of the mask.
        if not kodi.get_prop(SKIN_INTRO):
            kodi.set_prop(SKIN_INTRO, "1")
    else:
        kodi.clear_prop(SKIN_INTRO)
    kodi.log("session: intro_check new_process=%s intro=%s welcome=%s once=%s"
             % (new, play, welcome, once))
    return play, welcome

# -*- coding: utf-8 -*-
"""T44 weather self-repair for Open-Meteo (plan C / F26), run behind the profile-safe runner (origin/worker.py).

Why: `weather.openmeteo` 1.0.29 geolocates by IP exactly once - on its first service start with no `loc1`, it
creates an `addon_data/weather.openmeteo/geoip` marker and calls its GeoIP lookup. If that first attempt fails
(no network yet, DNS not ready) the marker stays and the location stays empty forever, so the home header shows
no weather. A tvOS cache purge or a cleared location has the same effect.

What (silently, per profile, no popups):
* `weather.location_override` set and not yet applied -> resolve that place with the public Open-Meteo geocoding
  API (the add-on's own search endpoint) and set it;
* else, location empty or invalid and `weather.auto_locate` on -> re-arm the add-on's OWN GeoIP by removing its
  stale `geoip` marker, so `weather.openmeteo` geolocates again on its next start (next profile load or Kodi
  start). NikeFlix does not call the add-on author's GeoIP service itself: it only serves the add-on's own
  user agent (403 otherwise, lab 2026-10-18) and impersonating that agent is not acceptable;
* otherwise nothing. A valid location chosen by the user is never overwritten.

Contract (same as the origin watchdog): COMPUTE runs on a worker with a FrozenEnv - file reads and one HTTPS
geocoding lookup (override only), no Kodi API, no writes. PUBLISH runs on the service thread and only if the
profile identity is unchanged: an override is written the same way the add-on's own location dialog does
(`loc1*`, user label cleared, update stamps reset so its service downloads on its next 5-minute loop); a re-arm
removes only the marker file. A small state file is kept in the active profile. Coordinates and place names are
never written to the Kodi log.
"""
import json
import os
import time
import xml.etree.ElementTree as ET
from urllib.parse import quote

PROVIDER = "weather.openmeteo"
S_AUTO = "weather.auto_locate"
S_OVERRIDE = "weather.location_override"
OM_SETTINGS = "special://profile/addon_data/weather.openmeteo/settings.xml"
STATE = "special://profile/addon_data/service.nikeflix/weather-state.json"
GEOIP_MARKER = "special://profile/addon_data/weather.openmeteo/geoip"   # created by the add-on's first-start GeoIP
SEARCH_URL = "https://geocoding-api.open-meteo.com/v1/search?name={}&count=10&language=en&format=json"
STALE_STAMP = "321318000"                                  # what the add-on writes to force a refresh
HTTP_TIMEOUT = 2.0         # short: the runner joins the worker for 2.5 s at profile end
START_DELAY = 90.0         # let the add-on's own first-start GeoIP run first
RETRY_S = 30 * 60.0        # still broken: try again later, quietly
LOOKUP_RETRY_S = 5 * 60.0  # a failed override lookup (network blip) retries sooner
RECHECK_S = 6 * 3600.0     # healthy: cheap file check now and then


def _bool(value, default):
    v = str(value or "").strip().lower()
    if v in ("true", "1"):
        return True
    if v in ("false", "0"):
        return False
    return default


def read_settings(path):
    """{id: value} from an add-on settings.xml (version 1 or 2), {} if missing or unreadable."""
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return {}
    out = {}
    for el in root.iter("setting"):
        sid = el.get("id")
        if sid:
            out[sid] = el.get("value") if el.get("value") is not None else (el.text or "")
    return out


def location_valid(om):
    """True when Open-Meteo has a usable location 1 (name plus real coordinates)."""
    if not str(om.get("loc1", "")).strip():
        return False
    try:
        lat, lon = float(om.get("loc1lat", "")), float(om.get("loc1lon", ""))
    except (TypeError, ValueError):
        return False
    if lat == 0.0 and lon == 0.0:
        return False
    return -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0


def choose(results, country=None, region=None):
    """Pick a geocoding result the way weather.openmeteo's own GeoIP path does."""
    if not results:
        return None
    for item in results:
        if country and region and country in str(item.get("country_code", "")) and region in str(item.get("admin1", "")):
            return item
    for item in results:
        if country and country in str(item.get("country_code", "")):
            return item
    return results[0]


def to_location(item):
    name = ", ".join(str(item.get(k)) for k in ("name", "admin1", "country_code") if item.get(k))
    return {"loc1": name, "loc1lat": str(item["latitude"]), "loc1lon": str(item["longitude"]),
            "loc1tz": str(item.get("timezone") or "")}


def fetch_json(url, timeout=HTTP_TIMEOUT):
    from urllib.request import Request, urlopen
    if not url.startswith("https://"):
        raise ValueError("https only")
    req = Request(url, headers={"User-Agent": "service.nikeflix-weather"})
    resp = urlopen(req, timeout=timeout)
    try:
        return json.loads(resp.read(512 * 1024).decode("utf-8"))
    finally:
        resp.close()


class WeatherModule(object):
    """Scheduling + compute/publish for one service (= one profile) lifetime."""
    SETTINGS = (S_AUTO, S_OVERRIDE)

    def __init__(self, env, guard_ready, fetch=fetch_json, start_delay=START_DELAY):
        self.env = env
        self.guard_ready = guard_ready
        self.fetch = fetch
        self.next_due = env.now() + start_delay
        self.last = None

    # ---- scheduling (service thread) ------------------------------------------------------------------
    def is_due(self):
        return self.env.now() >= self.next_due and self.guard_ready()

    def schedule_next(self, env):
        self.next_due = env.now() + RETRY_S       # shortened/extended by publish()

    # ---- worker ---------------------------------------------------------------------------------------
    def compute(self, fenv):
        provider = fenv.kodi_setting("weather.addon")
        if provider != PROVIDER:                   # only when the profile really uses Open-Meteo
            return {"action": "none", "reason": "provider"}
        if not os.path.isdir(fenv.translate("special://home/addons/" + PROVIDER)):
            return {"action": "none", "reason": "provider-missing"}
        auto = _bool(fenv.setting(S_AUTO), True)
        override = str(fenv.setting(S_OVERRIDE) or "").strip()
        om = read_settings(fenv.translate(OM_SETTINGS))
        state = self._state(fenv)
        valid = location_valid(om)
        if override and override != state.get("override_applied"):
            fenv.check()
            try:
                found = self.fetch(SEARCH_URL.format(quote(override))) or {}
            except Exception as exc:          # diagnosable without exposing the place: error classes only
                reason = getattr(exc, "reason", None)
                return {"action": "none", "reason": "lookup-failed:%s%s" % (
                    type(exc).__name__, (":" + type(reason).__name__) if reason is not None else "")}
            item = choose(found.get("results") or [])
            if not item:
                return {"action": "none", "reason": "override-not-found", "override": override}
            return {"action": "set", "source": "override", "override": override, "location": to_location(item)}
        if valid:
            return {"action": "none", "reason": "valid"}
        if not auto:
            return {"action": "none", "reason": "auto-off"}
        if os.path.exists(fenv.translate(GEOIP_MARKER)):
            return {"action": "rearm"}
        return {"action": "none", "reason": "awaiting-addon-geoip"}   # the add-on geolocates on its next start

    def _state(self, env):
        try:
            with open(env.translate(STATE), encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return {}

    # ---- service thread -------------------------------------------------------------------------------
    def publish(self, env, result):
        self.last = result
        action, reason = result.get("action"), result.get("reason")
        if action == "set":
            loc = result["location"]
            values = dict(loc)
            values.update({"loc1user": "", "loc1data": STALE_STAMP, "loc1map": STALE_STAMP,
                           "loc1rv": STALE_STAMP, "loc1gc": STALE_STAMP})
            try:
                for key in ("loc1", "loc1user", "loc1lat", "loc1lon", "loc1tz", "loc1data", "loc1map", "loc1rv", "loc1gc"):
                    env.set_addon_setting(PROVIDER, key, values[key])
            except Exception as exc:             # provider disabled or removed meanwhile: write nothing more
                env.log("weather override postponed: provider unavailable (%s)" % type(exc).__name__, "debug")
                self.next_due = env.now() + RETRY_S
                return
            state = self._state(env)
            state.update({"repaired_at": int(env.now()), "source": result["source"]})
            if result.get("override"):
                state["override_applied"] = result["override"]
            self._write_state(env, state)
            env.log("weather location set (source=%s); Open-Meteo refreshes on its next cycle" % result["source"])
            self.next_due = env.now() + RECHECK_S
        elif action == "rearm":
            try:
                os.remove(env.translate(GEOIP_MARKER))
            except OSError:
                pass
            state = self._state(env)
            state.update({"rearmed_at": int(env.now()), "source": "auto-rearm"})
            self._write_state(env, state)
            env.log("weather location missing: Open-Meteo GeoIP re-armed for its next start")
            self.next_due = env.now() + RECHECK_S
        elif reason in ("valid", "provider", "auto-off", "provider-missing", "awaiting-addon-geoip"):
            self.next_due = env.now() + RECHECK_S
        else:
            lookup = str(reason).startswith("lookup-failed")
            env.log("weather repair postponed: %s" % reason, "info" if lookup else "debug")
            self.next_due = env.now() + (LOOKUP_RETRY_S if lookup else RETRY_S)

    def publish_error(self, env, error_name):
        self.last = {"action": "none", "reason": "error:" + str(error_name)}
        env.log("weather repair postponed after %s" % error_name, "debug")
        self.next_due = env.now() + RETRY_S

    def _write_state(self, env, state):
        path = env.translate(STATE)
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(state, fh, sort_keys=True)
            os.replace(tmp, path)
        except Exception:
            pass


class WeatherEnv(object):
    """Service-thread environment for the weather module (wraps the shared Kodi adapter)."""
    ADDON_ID = "service.nikeflix"

    def __init__(self, kodi):
        self.k = kodi

    def translate(self, path):
        return self.k.translate(path)

    def now(self):
        return time.time()

    def log(self, message, level="info"):
        self.k.log("weather: " + message, level)

    def setting(self, key):
        try:
            import xbmcaddon
            return xbmcaddon.Addon(self.ADDON_ID).getSetting(key) or ""
        except Exception:
            return ""

    def set_addon_setting(self, addon_id, key, value):
        import xbmcaddon
        xbmcaddon.Addon(addon_id).setSetting(key, str(value))

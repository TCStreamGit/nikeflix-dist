# -*- coding: utf-8 -*-
"""Kodi access for the origin module, layered on the shared `Kodi` adapter (resources/lib/kodi.py).

The shared adapter is used unchanged (translate, builtin, log, properties, clock). This module adds only what
the watchdog and updater need: add-on settings, the platform, a Kodi setting read over JSON-RPC, an optional
notification and a size-capped HTTPS download. Tests replace `OriginEnv` with a fake that has the same methods.
"""
import json

ADDON_ID = "service.nikeflix"
def detect_platform(sys_platform=None, environ=None, machine=None):
    """windows | android | tvos | osx | linux | other, without any Kodi API call."""
    import os
    import sys
    sp = sys_platform if sys_platform is not None else sys.platform
    env = environ if environ is not None else os.environ
    if sp.startswith("win"):
        return "windows"
    if sp.startswith("linux"):
        return "android" if ("ANDROID_ROOT" in env or "ANDROID_DATA" in env) else "linux"
    if sp == "darwin":
        if machine is None:
            try:
                machine = os.uname().machine
            except Exception:
                machine = ""
        return "tvos" if str(machine).lower().startswith("appletv") else "osx"
    return "other"


def read_guisetting(path, key):
    """Persisted value of one Kodi GUI setting from a guisettings.xml file (pure file I/O), or None."""
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(path).getroot()
    except Exception:
        return None
    for el in root.iter("setting"):
        if el.get("id") == key:
            v = (el.text or "").strip()
            if el.get("default") == "true" and not v:
                return None
            return int(v) if v.lstrip("-").isdigit() else v
    return None


PLATFORM_CONDITIONS = (
    ("windows", "System.Platform.Windows"),
    ("android", "System.Platform.Android"),
    ("tvos", "System.Platform.TVOS"),
    ("osx", "System.Platform.OSX"),
    ("linux", "System.Platform.Linux"),
)


class OriginEnv(object):
    def __init__(self, kodi):
        self.k = kodi

    # --- delegated to the shared adapter -------------------------------------------------------------
    def translate(self, path):
        return self.k.translate(path)

    def builtin(self, command):
        self.k.builtin(command)

    def log(self, message, level="info"):
        self.k.log("origin: " + message, level)

    def get_prop(self, key):
        return self.k.get_prop(key)

    def set_prop(self, key, value):
        self.k.set_prop(key, value)

    def now(self):
        return self.k.now()

    def aborted(self):
        return self.k.aborted()

    # --- additions -----------------------------------------------------------------------------------
    def platform(self):
        """Platform from Python alone. Never xbmc.getCondVisibility here: called from the watchdog's
        background thread right after a profile load it was observed to block forever (lab 2026-10-18),
        which stopped Kodi from finalising the service on the next switch."""
        return detect_platform()

    def setting(self, key):
        """Raw string value of a service.nikeflix setting ('' if unknown)."""
        try:
            import xbmcaddon
            return xbmcaddon.Addon(ADDON_ID).getSetting(key) or ""
        except Exception:
            return ""

    def kodi_setting(self, key):
        """Persisted value of a Kodi GUI setting for the active profile (guisettings.xml), or None.

        Deliberately NOT xbmc.executeJSONRPC: it runs synchronously on Kodi's main loop and was observed
        to block the service right after a profile load, so Kodi killed the service on the next switch.
        Reading the persisted file is enough for drift reporting."""
        return read_guisetting(self.translate("special://profile/guisettings.xml"), key)

    def notify(self, heading, message):
        try:
            # builtin is queued to Kodi's main loop; no GUI call from the background thread
            safe = lambda v: str(v).replace(",", " ").replace(")", " ")
            self.k.builtin("Notification(%s,%s,5000)" % (safe(heading), safe(message)))
        except Exception:
            pass

    def http_get(self, url, dest, max_bytes, timeout=60):
        """Stream an HTTPS URL to `dest`, refusing more than `max_bytes`. Returns the byte count."""
        from urllib.request import Request, urlopen
        if not url.startswith("https://"):
            raise ValueError("only https downloads are allowed")
        req = Request(url, headers={"User-Agent": "service.nikeflix-origin"})
        total = 0
        resp = urlopen(req, timeout=timeout)
        try:
            with open(dest, "wb") as fh:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError("download exceeds %d bytes" % max_bytes)
                    fh.write(chunk)
        finally:
            resp.close()
        return total

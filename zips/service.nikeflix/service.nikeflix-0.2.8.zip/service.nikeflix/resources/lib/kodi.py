# -*- coding: utf-8 -*-
"""Thin adapter over the Kodi Python API so the guard and wrapper logic can be unit-tested with fakes.

Only this module imports xbmc*; everything else receives a `Kodi` instance.
"""
import time


class Kodi(object):
    """Real Kodi implementation (Python 3.8, xbmc.python 3.0.0)."""

    HOME_WINDOW = 10000

    def __init__(self):
        import xbmc
        import xbmcgui
        import xbmcvfs
        self._xbmc, self._xbmcgui, self._xbmcvfs = xbmc, xbmcgui, xbmcvfs
        self._home = xbmcgui.Window(self.HOME_WINDOW)
        self.monitor = xbmc.Monitor()

    # --- window properties (Home window is shared by every profile in one Kodi process) ---
    def get_prop(self, key):
        return self._home.getProperty(key)

    def set_prop(self, key, value):
        self._home.setProperty(key, value)

    def clear_prop(self, key):
        self._home.clearProperty(key)

    # --- environment ---
    def translate(self, path):
        return self._xbmcvfs.translatePath(path)

    def cond(self, condition):
        return bool(self._xbmc.getCondVisibility(condition))

    def builtin(self, command):
        self._xbmc.executebuiltin(command)

    def now(self):
        return time.time()

    def wait(self, seconds):
        """Returns True when Kodi asks the script to abort (profile switch or shutdown)."""
        return self.monitor.waitForAbort(seconds)

    def aborted(self):
        return self.monitor.abortRequested()

    def log(self, message, level="info"):
        lvl = {"debug": self._xbmc.LOGDEBUG, "info": self._xbmc.LOGINFO,
               "warning": self._xbmc.LOGWARNING, "error": self._xbmc.LOGERROR}[level]
        self._xbmc.log("[service.nikeflix] " + message, lvl)

    def player(self, on_av_started):
        """Player whose onAVStarted calls `on_av_started` (playback really started)."""
        xbmc = self._xbmc

        class _Player(xbmc.Player):
            def onAVStarted(self):
                on_av_started()

        return _Player()

    def countdown_cancelled(self, heading, message, seconds):
        """Cancellable countdown before the fallback starts. Returns True if the user cancelled."""
        if seconds <= 0:
            return False
        dialog = self._xbmcgui.DialogProgress()
        dialog.create(heading, message)
        try:
            steps = int(seconds * 10)
            for i in range(steps):
                if dialog.iscanceled() or self.monitor.abortRequested():
                    return True
                dialog.update(int(100 * i / steps))
                self.monitor.waitForAbort(0.1)
            return dialog.iscanceled()
        finally:
            dialog.close()

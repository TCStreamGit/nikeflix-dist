"""The eight NikeFlix Sports rows, independent of any IPTV provider or add-on.

Rows are built from Kodi's own PVR channel list (JSON-RPC ``PVR.GetChannelGroups`` / ``PVR.GetChannels``), so they
work with any PVR client: IPTV Simple fed directly, through a bridge, or anything chosen at T40. The grouping and
ordering rules are ``sports.rules`` (the NikeFlix live-guide rules). Nothing here knows a provider, a URL or a
credential: channels are played by Kodi channel id.

Navigation contract (unchanged from the legacy rows; only the owner changed):
    plugin://service.nikeflix/?mode=live_guide_group&group_key=<key>&page=<n>
"""
from . import rules

# Hub rows 510..580, in order (config/common/skin.yml bingiehub-new-5x0)
ROW_KEYS = ("basketball", "hockey", "nfl", "cfl", "formula_one", "nascar", "wrestling", "soccer_all")
PAGE_SIZE = 40
ALL_GROUP_IDS = ("alltv",)


def rows_from_pvr(groups):
    """groups: [(group_label, [PVR channel dicts])] -> rule-ready rows, one per channel id.

    A channel's category is the first non-"all channels" group it appears in, mirroring Xtream categories."""
    rows, order = {}, []
    for label, channels in groups:
        for ch in channels or []:
            cid = ch.get("channelid")
            if cid is None or ch.get("hidden"):
                continue
            now = ch.get("broadcastnow") or {}
            if cid not in rows:
                rows[cid] = {"stream_id": cid, "channelid": cid, "name": ch.get("label") or ch.get("channel") or "",
                             "category_name": label or "", "now_title": now.get("title") or "",
                             "now_description": now.get("plot") or now.get("plotoutline") or "",
                             "has_current_program": bool(now.get("title")),
                             "tv_archive": 1 if ch.get("hasarchive") else 0,
                             "icon": ch.get("thumbnail") or ch.get("icon") or ""}
                order.append(cid)
            elif not rows[cid]["category_name"] and label:
                rows[cid]["category_name"] = label
    return [rows[c] for c in order]


def group_page(rows, group_key, page=1, page_size=PAGE_SIZE):
    """(items, has_next, page) for one row; unknown keys give an empty page."""
    if not rules.get_group(group_key):
        return [], False, 1
    matched = rules.match_streams(rows, group_key)
    page = max(1, int(page or 1))
    start = (page - 1) * page_size
    return matched[start:start + page_size], len(matched) > start + page_size, page


class PvrSource(object):
    """Reads channels through a JSON-RPC callable ``rpc(method, params) -> result | None``."""

    PROPS = ["channel", "hidden", "thumbnail", "broadcastnow"]

    def __init__(self, rpc):
        self.rpc = rpc

    def _channels(self, group_id):
        for props in (self.PROPS + ["hasarchive"], self.PROPS):
            res = self.rpc("PVR.GetChannels", {"channelgroupid": group_id, "properties": props})
            if res is not None:
                return res.get("channels") or []
        return []

    def rows(self):
        groups = (self.rpc("PVR.GetChannelGroups", {"channeltype": "tv"}) or {}).get("channelgroups") or []
        named = [(g.get("label", ""), self._channels(g["channelgroupid"])) for g in groups
                 if not g.get("hidden") and g.get("channelgroupid") not in ALL_GROUP_IDS]
        named.append(("", self._channels("alltv")))      # channels that belong to no named group
        return rows_from_pvr(named)

# NIKEFLIX-CHANGES: Skin NikeFlix modification log

Skin NikeFlix is a modified version of Titan BINGIE MOD 2.2.8 (GPL-2.0-only).

- This file is the prominent change notice required by GPL-2.0 section 2(a).
- Each entry records the date, the task in the NikeFlix rebuild plan (`OBJ-NFX-NG-01`), and the files changed.
- The upstream baseline is commit `9b42241` of this repository: the unmodified legacy NikeFlix copy of `skin.titan.bingie.mod` 2.2.8.

## 2026-11-11: 1.1.13 lands on main (H3 Option C, approved by Tanner)

- The 1.1.0-1.1.13 entries below were developed on `staging/h3-option-c` (now tag `archive/20261111/staging/h3-option-c`). They are now in the main skin, next to the 1.0.0 fixes of the same day (PO label, screenshots, D6 `Textures.xbt`). Their "lab candidate" / "staged, not released" labels describe the state at the time. Nothing is published yet; publication is the T63 step.
- `addon.xml` news: one short 1.1.13 summary instead of the per-revision list (the strict kodi-addon-checker schema refused the long text, F4 gate).
- Files: `addon.xml`, `NIKEFLIX-CHANGES.md`.

## 2026-11-02: 1.1.13, lab candidate, not staged (H3-DEADLOCK-SKIN-GATE-01, DEC-H3-SKIN-GATE-INTEGRATION-01)

- **A stale switch marker no longer holds the menu rebuild back for good.** 1.1.12 skipped Home's `buildxml` while `nikeflix.quiesce` was set. If service.nikeflix died after taking a switch over, or was enabled-but-dead at a playback click, the marker stayed until the next switch, login or restart. Now the first Home init held back by a marker value arms `nikeflix_sscgate` (3 min, far beyond any live switch: playback stop <= 15 s plus the 45-s cap, or the 40-s fallback); it records that value as released, and while the marker still holds exactly that value Home rebuilds again. A live switch changes the marker (new token, login screen) or ends long before; nothing clears the marker itself. An empty or `login:` marker clears this state and cancels the alarm.
- Window properties (`nikeflix.sscgate.armed`, `nikeflix.sscgate.released`) and one named alarm only; no skin setting is read, written or referenced.
- Files: `xml/Home.xml`, `addon.xml`.

## 2026-11-02: 1.1.12, lab candidate, not staged (H3-DEADLOCK-SKIN-GATE-01, DEC-H3-RB10-SKIN-GATE-REVIEW)

- **No Skin Shortcuts menu rebuild from Home while a profile switch is pending.** `Home.xml`'s `buildxml` onload now also needs `Window(Home).Property(nikeflix.quiesce)` empty or the login screen's own `login:` marker. A switch during playback stops the player first; Home re-initialised then and started this rebuild, which was still in `xbmcvfs.translatePath` (it keeps the Python GIL) when LogOff took the profile manager's lock - the deadlock of lab run `rb10-ER-reg` (platform `docs/evidence/H3-PROFILE-SWITCH-HANG.md`). The marker is the switch's own (the click's `switch:` marker or service.nikeflix's `deadline:token` request); it ends when the switch is abandoned, refused by the gate or reaches the login screen, so the next Home, and the destination profile's Home, rebuild as before. One Skin Shortcuts run builds every profile's menus, so a skipped rebuild loses nothing.
- Window properties only: no skin setting is read, written or referenced; no new property or alarm.
- Files: `xml/Home.xml`, `addon.xml`.

## 2026-10-28: 1.1.11, staged, not released (H3-FAM-STARTUP-01, settings-persistence invariant)

- **Home's first init in a new Kodi process writes nothing on an initialised profile.** `DefaultSkinSettings` (in `Home.xml` and the settings windows) applies `DefaultSkinSettingsValues` whenever `Window(Home).Property(startupDone)` is empty, i.e. on the first Home init of every Kodi process. On a cross-profile cold start (login screen -> another profile) that init still runs on the previous profile's skin object, after Kodi has mapped the new profile and before its first skin reload; the lab (192.168.1.56, 1.1.10 cold restarts) showed six writes there, each arming the old object's save, cancelled at the reload with about 0.23 s to spare. These are the same writes that put master's settings into NikeFlix User 3 on 1.1.9, moved from `Startup.xml` to Home.
  - The five `CompareTxt*` constants are written only when they differ.
  - `defaultcolorpalette.label` is set only while the one-time defaults run (`!Skin.HasSetting(HomeMenuDefaults46)`); skin helper owns the label afterwards (it cleared it, and the skin wrote it again in every new process).
- **Correction to the 1.1.10 entry below:** "the one-time defaults still apply ... on the profile's own skin object" holds for profile switches, not for a cross-profile cold start (above). The 1.1.10 news text claimed that one profile's settings cannot reach another's; it is narrowed to what was shown.
- Files: `xml/IncludesDefaultSkinSettings.xml`, `addon.xml`. `Startup.xml` / `Home.xml` are unchanged (still the lab candidate `home-nostartup-nsd`). Evidence: platform `docs/evidence/H3-FAMILY-STARTUP-WELCOME.md`.

## 2026-10-27: 1.1.10, staged, not released (H3-FAM-STARTUP-01, lab candidate home-nostartup-nsd)

- **`Startup.xml` makes no skin-setting write.** Kodi 21.3 runs `Startup.xml` before the post-load skin reload, on the previous profile's skin object, so every write there acted on the profile being left. Its pending 500-ms save could then write that profile's skin settings into the newly loaded profile's file (lab, 192.168.1.56: master's settings in NikeFlix User 3 at a cold restart; Family Profile 3's settings in master's file under load). Removed: `Skin.SetBool(TMDbHelper.Service)`, `Skin.SetString(TMDbHelper.MonitorContainer,99950)` and the `DefaultSkinSettings` include. The one-time defaults still apply from `Home.xml` (and the settings windows) on the profile's own skin object; the lab showed the same end values and gates.
- **`Home.xml` writes `TMDbHelper.MonitorContainer` only when it differs from 99950** (it was rewritten on every Home init). It is still set where it is missing. TMDb Helper stays installed and enabled; `TMDbHelper.Service` is neither forced nor changed; no seed or defaults gate is changed.
- 1.1.9 (`Startup.xml`'s TMDb writes only) was staged and reverted the same day: its proof found master's settings in NikeFlix User 3 through the `DefaultSkinSettings` include, which 1.1.10 also removes.
- Files: `xml/Startup.xml`, `xml/Home.xml`, byte-identical to the lab candidate `home-nostartup-nsd` (`a423e1dc…`). Evidence: platform `docs/evidence/H3-FAMILY-STARTUP-WELCOME.md`.

## 2026-10-24: 1.1.8, staged, not released (H3 cleanup correction, staging review)

- **No marker left behind:** a Switch-profile click while something plays sets the `nikeflix.quiesce` request marker only when service.nikeflix is enabled (`!Player.HasMedia | System.AddonIsEnabled(service.nikeflix)`). With the service disabled the click only arms the notice; before, the marker stayed until the next profile switch and, read from a time of day as a 12- or 24-hour clock, parked the gated loops again for up to 90 s every 12 hours. No-media clicks are unchanged (the marker parks the loops before the gate's fallback LogOff).
- Files: `xml/IncludesBingie.xml`, `xml/IncludesHeader.xml`, `xml/script-skinshortcuts-includes.xml` (6 Switch-profile sites), `shortcuts/overrides.xml` (the marker override split from the wake-up).

## 2026-10-22: 1.1.7, staged, not released (H3 switch gate, DEC-H3-MODAL-STAGING review)

- **No global dialog close:** 1.1.6's `nikeflix_close` alarm (`Dialog.Close(all,true)` in the same alarm pass as the LogOff) and its `nikeflix_anchor` are withdrawn. It could dismiss an unrelated dialog, and the alarm pass it relied on is Kodi implementation behaviour (`CAlarmClock::Stop` posts each builtin with `PostMsg`; other threads can queue messages in between), not an atomic guarantee. `Custom_1199` arms only the 0-s `nikeflix_switch` LogOff after its check; only the power menu is ever closed (`Custom_1198`, and `DialogButtonMenu.xml` while logging off).
- **Known limit (kept, release-blocking):** a dialog other than the power menu that opens in the <= 0.1 s between stage 2's check and the LogOff, or during the LogOff itself, still makes Kodi refuse the login screen.
- Files: `xml/Custom_1199_NikeFlixSwitchCheck.xml`, `xml/LoginScreen.xml` (no anchor to cancel).

## 2026-10-22: 1.1.6, staged, not released (H3 switch gate, DEC-H3-MODAL-STAGING)

- **The last gap closed:** between gate stage 2's check and the LogOff Kodi's alarm thread takes up to 0.1 s; in the lab a text-viewer dialog aimed at that gap still made Kodi refuse the login screen, and leaving a non-master profile every recovery from there froze or crashed Kodi (4 of 5). `Custom_1199` now arms, in this order, a pending `nikeflix_anchor`, a 0-s `nikeflix_close` (`Dialog.Close(all,true)`) and the 0-s `nikeflix_switch` LogOff: Kodi's alarm thread fires the two 0-s alarms in one pass in name order (the pending anchor keeps the pass going) and the main thread runs them back to back, so a dialog opened after the check - which cannot hold typed input - is closed right before the LogOff. A dialog open at the check is never closed (the switch is dropped instead). `xml/LoginScreen.xml` also cancels the anchor.
- **Recovery removed:** `Custom_1197_NikeFlixSwitchRecover.xml` and Home's `stranded` marking are gone; `xml/Home.xml` still skips the Skin Shortcuts rebuild while the gate says `logoff` (Home is initialised inside the LogOff).
- Files: `xml/Custom_1199_NikeFlixSwitchCheck.xml`, `xml/Home.xml`, `xml/LoginScreen.xml`; `xml/Custom_1197_NikeFlixSwitchRecover.xml` removed.

## 2026-10-22: 1.1.5, staged, not released (H3 switch gate, DEC-H3-MODAL-STAGING)

- **No power menu while logging off:** `xml/DialogButtonMenu.xml` `<onload>` closes the power menu at once while `nikeflix.gate` is `logoff` (between gate stage 2 and the login screen). In the lab the power menu reopened in that <= 0.1 s gap (every 0.5 s, or aimed at it) was the only dialog that still made Kodi refuse the login screen. Kodi's own `CGUIDialog::Open_Internal` closes a dialog right after its init the same way; the modal loop then ends.
- **Home marks, `Custom_1197` activates:** 1.1.4's synchronous `ActivateWindow(loginscreen)` from Home's `<onload>` (inside Kodi's skin load after a refused login screen) crashed Kodi in 2 of 2 lab strands; `xml/Home.xml` again only marks `stranded` (and still skips the Skin Shortcuts rebuild in that state) and `Custom_1197` activates the login screen through a 0-s alarm.
- Files: `xml/DialogButtonMenu.xml`, `xml/Home.xml`.

## 2026-10-22: 1.1.4, staged, not released (H3 switch gate recovery, DEC-H3-MODAL-STAGING)

- **Strand recovery from Home itself:** leaving a non-master profile, a refused login screen leaves Kodi reloading the skin in the master profile (dialogs closed) and showing Home. In the lab (1.1.3 and stock 1.1.1 alike) Skin Shortcuts' `buildxml`, started by that Home, reloaded the skin a second time and Kodi froze in that reload. `xml/Home.xml` `<onload>` now activates the login screen at once when the gate is `logoff`/`stranded` and no modal dialog is open, marks `stranded` (for `Custom_1197`) when one is, and skips the Skin Shortcuts rebuild in that state (all conditions are evaluated before any action runs).
- Files: `xml/Home.xml`.

## 2026-10-22: 1.1.3, staged, not released (H3 switch gate recovery, DEC-H3-MODAL-STAGING)

- **Refused login screen, recovered:** between the gate's check and the LogOff Kodi's alarm thread takes up to 0.1 s; a dialog opened in that gap (lab: the power menu reopened every 0.5 s) still makes Kodi refuse the login screen. Leaving a profile other than the master, Kodi then reloads the skin and shows Home in the master profile with no service running. Stage 2 now marks `nikeflix.gate=logoff` when it arms the LogOff; `xml/Home.xml` `<onload>` turns that into `stranded`; the new modeless `xml/Custom_1197_NikeFlixSwitchRecover.xml` (visible only while `stranded`, no modal dialog and no login screen) activates the login screen through a 0-s alarm - the one step the LogOff skipped, not a second LogOff - and retries whenever a dialog closes. The login screen's `<onload>` clears the gate. Leaving the master profile, service.nikeflix 0.2.3 (still running) does the same.
- Files: `xml/Custom_1197_NikeFlixSwitchRecover.xml` (new), `xml/Custom_1199_NikeFlixSwitchCheck.xml`, `xml/Home.xml`.

## 2026-10-22: 1.1.2, staged, not released (H3 switch gate, DEC-H3-MODAL-STAGING)

- **Switch gate:** Kodi 21.3's `System.LogOff` loads the master profile and then activates the login screen once; the window manager refuses that while a modal dialog is open, which strands the switch on Home (lab: the power menu reopened while the switch waited; stock `System.LogOff` the same). The one `nikeflix_switch` alarm no longer runs `System.LogOff` itself: without media it runs `SetProperty(nikeflix.gate,go,home)`. Two new modeless dialogs (a `<visible>` condition each, so neither blocks anything): `Custom_1198_NikeFlixSwitchGate.xml` force-closes the power menu (`shutdownmenu`, nothing else) and hands over to `Custom_1199_NikeFlixSwitchCheck.xml`, whose conditions are evaluated after that close: with no modal dialog (`System.HasActiveModalDialog`, exactly what refuses the login screen), nothing playing and no login screen up it arms `AlarmClock(nikeflix_switch,System.LogOff,00:00:00,silent)` (never LogOff from Kodi's frame loop); otherwise it clears `nikeflix.quiesce` and shows a notice. This holds when service.nikeflix is disabled, late or crashed too.
- `xml/LoginScreen.xml` `<onload>` also cancels any `nikeflix_switch` alarm and clears `nikeflix.gate`: a switch is over once the login screen is up.
- Files: `xml/Custom_1198_NikeFlixSwitchGate.xml`, `xml/Custom_1199_NikeFlixSwitchCheck.xml` (new), `xml/IncludesBingie.xml`, `xml/IncludesHeader.xml`, `xml/script-skinshortcuts-includes.xml` (6 onclick sites), `shortcuts/overrides.xml`, `xml/LoginScreen.xml`. Layout unchanged.
- Rollback: restoring these files to 1.1.1 (and deleting the two gate files) restores the direct LogOff alarm.

## 2026-10-21: 1.1.1, staged, not released (H3 playback preflight, DEC-H3-PLAYBACK-STAGING)

- **Switch profile while something plays:** the switch alarm is armed with `System.LogOff` only under `!Player.HasMedia`; under `Player.HasMedia` the same `nikeflix_switch` alarm carries `Notification(NikeFlix,Profile not switched - stop playback and try again,8000)` instead. service.nikeflix 0.2.1 cancels that alarm, stops the player, waits for proof that the player is gone and for fresh loop acknowledgements, and only then arms the LogOff; without the service a click during playback switches nothing and shows the notice. The marker and the wake-up are unchanged; without playback the three builtins are exactly 1.1.0's.
- Files: `xml/IncludesBingie.xml`, `xml/IncludesHeader.xml`, `xml/script-skinshortcuts-includes.xml` (6 onclick sites: the alarm split into two conditional onclicks), `shortcuts/overrides.xml` (the `System.LogOff` override split into a `!Player.HasMedia` alarm, a `Player.HasMedia` notice alarm and the unconditional marker and wake-up). Layout unchanged.
- Rollback: restoring these files to 1.1.0 restores the unconditional LogOff alarm.

## 2026-10-21: 1.1.0, staged, not released (H3 Option C, DEC-H3-C-STAGING)

- **Switch profile** (every `System.LogOff` entry point) runs, in order: `AlarmClock(nikeflix_switch,System.LogOff,00:00:40,silent)` (the one LogOff of the switch; it always fires), `SetProperty(nikeflix.quiesce,switch:$INFO[System.Time(hh:mm:ss)],home)` (parks the gated service loops) and `NotifyAll(service.nikeflix,profile_switch)`. service.nikeflix 0.2.0 moves that alarm once the profile has settled and the loops have acknowledged. Evidence: platform `docs/evidence/H3-QUIESCE-V5.md`.
- Files: `xml/IncludesBingie.xml`, `xml/IncludesHeader.xml`, `xml/script-skinshortcuts-includes.xml` (6 onclick sites), `shortcuts/overrides.xml` (Skin Shortcuts `System.LogOff` override, power menu), `xml/LoginScreen.xml` (`<onload>` sets `nikeflix.quiesce=login:<hh:mm:ss>`, `<onunload>` clears it). Layout unchanged.
- Rollback: restoring these files to 1.0.0 makes every service gate inert.

## 2026-10-19: unreleased (T41, per-profile feature toggles)

- **Single source of truth:** the per-profile skin settings `nikeflix.feature.sports`, `nikeflix.feature.pvr` and `nikeflix.feature.live`. nfbuild writes their defaults from each profile's YAML (Regular ON×5; Family ON/OFF/ON/OFF/OFF). Skin settings are stored per profile, so a change in one profile never touches another.
- `xml/IncludesSkinSettings.xml`, `xml/SkinSettings.xml`:
  - new **NikeFlix features** tab (menu button `40`, added **last** so the existing tab order is unchanged; hidden in the compact `Custom_1105` settings window);
  - three radio buttons (`40101`–`40103`) running `Skin.ToggleSetting(nikeflix.feature.*)`;
  - a note that the switches only show or hide menus and never add, remove or share an account.
- **Main menu:** the items "Sports & Live Events" (window 1112) and "PVR Hub" (window 1116) are visible only while their setting is on.
  - nfbuild writes `<visible>` into the profile's skinshortcuts `mainmenu.DATA.xml`, and skinshortcuts 2.1.0 carries it into the menu it builds.
  - The shipped `xml/script-skinshortcuts-includes.xml` carries the same conditions until skinshortcuts rebuilds.
- **Window guards:** each `onload` returns to Home when the feature is off, so a widget, favourite or remote shortcut cannot open a hidden area.
  - `Custom_1112_New_Hub.xml` (sports) and `Custom_1116_PVR_Hub.xml` (pvr).
  - `MyPVRGuide.xml`, `MyPVRChannels.xml`, `MyPVRRecordings.xml`, `MyPVRTimers.xml` and `MyPVRSearch.xml` (live).
- New strings `32920`–`32925` (T41 block; the T52 block 32910–32919 stays unused).

## 2026-10-18: unreleased (T52, deterministic Home focus)

- **Root cause (lab, `docs/evidence/T52-HOME-FOCUS.md`):** the hidden Home init button `1000` sent focus to the widget grouplist `77777` on every Home init. During a profile load the widget rows are still loading:
  - on a cold start no row could take focus yet, so focus stayed on button `1000`, which had no `<ondown>`: the first Down did nothing;
  - on a profile switch focus landed on the empty, still-updating spotlight row `1508`: the first Right did nothing, and focus later jumped back to `1508` without input.
- `xml/Startup.xml` (every profile load) sets the Home property `NikeFlix.Home.LoadFocus=1` and cancels the previous expiry alarm.
- `xml/Home.xml`:
  - While `NikeFlix.Home.LoadFocus` is set, button `1000` and an onload both focus the main menu with `$VAR[DefaultMenuFocus]` (list `900`, optionally the item from `home.defaultfocus`). The menu items are static, so the focus does not depend on widget loading.
  - The legacy widget focus (`77777`) and the `AutoFocusHome` choice apply only when the flag is clear, for example when returning to Home from a hub.
  - Home-ready without the intro mask and without a first-run window starts a 30 s alarm `nikeflix_loadfocus` that clears the flag. The skin reloads of a profile load re-init Home within that window and keep the menu focus.
  - Button `1000` gains `<onup>`/`<ondown>` → `900`, so it is never a dead end.
- `xml/Custom_1103_StartUpMask.xml`: the armed mask keeps the flag (no expiry under the mask). When the mask really closes, a 0 s alarm `nikeflix_homefocus` reasserts `SetFocus($VAR[DefaultMenuFocus])` on Home and the 30 s expiry starts. The mask blocks input until then, so this cannot undo a user's navigation.
- Focus is set only on window init and mask close, never on user input.
- First-run windows 1101/1102 are unchanged: they open only while the profile's `BingieFirstStartupDone`/`BingieSecondStartupDone` are unset.
- No new skin strings. The T52 block 32910–32919 stays unused.

## 2026-10-18: unreleased (T51, intro once per Kodi process)

- `xml/Startup.xml` runs on every profile load and no longer sets the Home property `StartupMask`.
  - It calls `RunScript(service.nikeflix,action=intro_check)`. The service sets the Home property `NikeFlix.Intro.Play=1` only for the first profile load of a Kodi process (a Home-window PID marker; see `service.nikeflix/resources/lib/session/`), and clears it otherwise.
  - **Fast path:** while there is no session marker (`nikeflix.session.pid`) and no `NikeFlix.Intro.Seen`, the load is the first one of the Kodi process. The skin then arms the mask at once, and the service only confirms it. During a profile load RunScript took about 3.6 s in the lab, and Home would have been visible until it returned.
  - Without an enabled `service.nikeflix`, the same `NikeFlix.Intro.Seen` Home marker still limits the intro to one per process.
- `xml/Custom_1103_StartUpMask.xml`:
  - The mask is visible while `NikeFlix.Intro.Play` is set, instead of `StartupMask`.
  - Every onload action is one-shot: it runs only while the property is `1`, and the same onload list moves it to `started`. Kodi evaluates the conditions before it runs the actions, so the re-inits of this dialog during a profile load (the skin reload re-opens it) no longer restart the clip. There is exactly one `PlayMedia` per trigger; legacy opened the clip two or three times.
  - The timer clears `NikeFlix.Intro.Play`, which closes the mask. A 30 s failsafe timer guarantees that the input-blocking mask never stays open.
  - `StartupMask` is still set while the mask is up, for the spotlight-trailer delays in `IncludesFunctions.xml`.
  - **Extended splash fixed:** the invalid `$INFO[mediaPath,…]` wrapper is gone. "NikeFlix Extended" plays `nikeflix_intro_1080p.mp4` and then shows the splash image until 22 s.
  - Default, Alternative and any unknown value play `$VAR[NikeFlixIntroClip]`. The 1080p/4K setting picks the 2160p clip; an empty or unknown resolution (fresh profile) falls back to the 1080p clip. "None" shows the splash image only.
  - **Welcome toast:** shown once per Kodi process, for the first profile, when the mask really closes (`NikeFlix.Welcome.Show`, set by the service). Previously it was shown on every profile switch.
- `xml/IncludesVariables.xml`: new variable `NikeFlixIntroClip`.
- No new skin strings. The T51 block 32900–32909 stays unused.
- Home default focus after the mask: see the T52 entry above.

## 2026-10-18: 1.0.0 (T22, fork-out)

### Identity and licence

- `addon.xml`:
  - The id changes from `skin.titan.bingie.mod` to `skin.nikeflix`, the name to "Skin NikeFlix" and the version to `1.0.0`.
  - The licence tag changes from `GPL v2.0` to the SPDX form `GPL-2.0-only`.
  - `provider-name` credits the Titan, Titan BINGIE and Titan BINGIE MOD authors.
  - The summary, description and news are rewritten.
  - The upstream forum, website and source URLs are removed, because NikeFlix users must not be sent to upstream support. Upstream remains credited in `NOTICE.md` and `CREDITS.md`.
- The `<requires>` imports are unchanged. Each one was checked against `managed-addons.yml`; all 12 non-core imports are class **M**, and the live and archive versions meet every minimum:
  - `script.skinshortcuts` 2.1.0 ≥ 2.1.0
  - `script.skin.helper.service` 1.30.0 ≥ 1.30.0
  - `script.skin.helper.widgets` 1.30.0
  - `script.skin.helper.backgrounds` 1.0.36
  - `script.bingie.helper` 1.1.2
  - `plugin.video.themoviedb.helper` 6.16.1 ≥ 5.2.12
  - `plugin.program.autocompletion` 2.1.3 ≥ 2.1.2
  - `plugin.video.youtube` 7.4.4 ≥ 7.0.2.2
  - the four `resource.images.*` packs
  - `xbmc.gui` 5.17.0 is Kodi core.
- Added `NOTICE.md`, `CREDITS.md` and this file. `LICENSE` is unchanged.
- `README.md` gains a NikeFlix header. The upstream text and credits are kept below it.

### Visible branding

- `language/resource.language.en_gb/strings.po`:
  - `#320029` "Exit Bingie" becomes **"Exit NikeFlix"**.
  - `#31387` becomes "Welcome to NikeFlix".
  - `#31388` (layout intro text) and `#31395` (widgets intro text) are rewritten for NikeFlix.
  - The "Bingie Mod Logo" setting strings become "NikeFlix Logo".
  - The startup-animation option labels become "NikeFlix Default", "NikeFlix Alternative" and "NikeFlix Extended" (`#320189`, `#320236`, `#320190`).
  - Every other visible "Bingie" / "BINGIE MOD" becomes "NikeFlix".
  - Product uses of "Netflix" become "NikeFlix", for example "Who's watching NikeFlix?".
  - "Netflix Original Series/Movies" (`#31181`, `#31182`) are kept, because they name third-party content, not the product.
  - The header comment now names `skin.nikeflix`.
- `fr_fr` and `nl_nl`: the same ids get the equivalent rewrite in `msgid` and `msgstr`. For example, `#320029` becomes "Quitter NikeFlix" and "NikeFlix afsluiten".
- `xml/IncludesDefaultSkinSettings.xml`: the default `HomeLayout.label` is now `[UPPERCASE]NikeFlix[/UPPERCASE]`.
- `xml/script-skinshortcuts-includes.xml` and `shortcuts/*.DATA.xml` contain **no literal "Exit Bingie"**. The power-menu exit item is `$LOCALIZE[320029]` / `<label>320029</label>` with `Quit()`, so the strings.po change rebrands it. The main-menu order and labels are unchanged.
- Internal identifiers that contain "bingie" are **kept**: file names, include and variable names, the `HomeLayout` value `bingie`, the `splash_screen` values `netflix_*`, and `script.bingie.helper`. There are about 2,700 of them, and renaming them would break stored skin settings, generated skinshortcuts includes and helper add-ons.

### Reserved string IDs

`strings.po` IDs **32900–32999** are reserved for later skin tasks. The header of every `strings.po` documents this. No skin string uses them yet.

| IDs | Task |
|---|---|
| 32900–32909 | T51 intro once per Kodi process |
| 32910–32919 | T52 Home focus |
| 32920–32929 | T53 Exit NikeFlix and shutdown mask |
| 32930–32949 | T33 Trakt Account window |
| 32950–32959 | T39 hub rewiring |
| 32960–32979 | T41 PVR / Sports / Live |
| 32980–32989 | T44 header |
| 32990–32999 | spare. Allocate it here first. |

### Intro clips

- The 12 legacy MP4s held **4 distinct contents** (by sha256).
- All 4 are NikeFlix's own intro: their XMP names a NikeFlix Premiere Pro project, and the frames show the NikeFlix logo. This closes `LICENSE-AUDIT.md` L6.
- The skin XML only ever resolved two of them: the 4-second clip at 1080p and at 2160p. The unreferenced 10-second versions are not shipped.

| Shipped file | Legacy files with identical content |
|---|---|
| `extras/media/nikeflix_intro_1080p.mp4` | `bingie_intro_1080p`, `netflix_intro_1080p`, `netflix_intro_1080p1`, `netflix_intro_1080p2`, `netflix_intro_extended_1080p` |
| `extras/media/nikeflix_intro_2160p.mp4` | `bingie_intro_2160p`, `netflix_intro_2160p`, `netflix_intro_2160p1`, `netflix_intro_2_1080p`, `netflix_intro_2_2160p` |

- **Metadata stripped:**
  - The clips were re-muxed with `ffmpeg -map_metadata -1 -map_chapters -1 -c copy` and bitexact flags.
  - This removed the creation times, the encoder tags and the XMP packet, which embedded a personal path.
  - The audio and video streams are bit-identical to the originals (ffmpeg `streamhash` sha256).
- `xml/Custom_1103_StartUpMask.xml`:
  - The `PlayMedia` paths now use `nikeflix_intro_<SplashAnimationResolution>.mp4`.
  - **Behaviour note:** the legacy "default" option played `netflix_intro_2_<res>.mp4`, and both of those files were the 2160p encode. The default option now honours the 1080p/4K setting (`#31075`) and plays the same clip at the chosen resolution.
  - The "extended" option keeps its legacy `$INFO[mediaPath,…]` wrapper. That wrapper is not a valid info label, so legacy showed only the splash image. Its target now points at an existing file. Revisit this in T51 (done: see the T51 entry).
- **Fresh-profile guard:**
  - The resolution-based `PlayMedia` lines now also require a non-empty `SplashAnimationResolution`.
  - When that setting is empty, the skin plays `nikeflix_intro_1080p.mp4` instead.
  - The new skin id starts every profile with empty skin settings. In the lab, the legacy expression then produced `PlayMedia()` with an empty path, followed by an empty "OK" dialog (`docs/evidence/T22-SKIN-SMOKE.md`).
- The setting values (`netflix_default`, `netflix_alternative`, `netflix_extended`, `none`) are unchanged, so every stored splash choice still resolves.

### Fonts

- Removed the proprietary `Netflix-Sans-Light.ttf`, `Netflix-Sans-Medium.ttf`, `Netflix-sans-Bold.ttf` and `Impact.ttf` (`LICENSE-AUDIT.md` L2/L3).
- Added Inter Light/Medium/Bold and Anton Regular, all SIL OFL 1.1, with their licence texts. Added the Apache-2.0 text for the inherited Roboto files.
- `xml/Font.xml` is repointed. `IBold30` uses Anton at size 28 to match Impact's cap height. The case of the Roboto `Bold-New.ttf` filename is fixed to match the file `Bold-new.ttf`.
- See `fonts/FONTS.md` for sources, checksums and metric checks.

### Textures

- Added `media-src/`:
  - `textures/`: lossless PNG sources for all 1,796 `Textures.xbt` entries.
  - `TEXTURES-MANIFEST.tsv`.
  - `xbt_tool.py`: a stdlib XBT reader/writer with LZO1X decompression.
- `media/Textures.xbt` gains `nikeflix/nikeflix_logo_home.png` and `nikeflix/nikeflix_logo.png`, whose pixels are identical to the legacy `home/bingie_mod_logo.png` and `bingie_mod_logo.png`. All 1,794 legacy entries are byte-identical.
- These files now reference the new entries instead of the "bingie" logo names:
  - `xml/Custom_1101_StartUp.xml`
  - `xml/Custom_1102_StartUp2.xml`
  - `xml/IncludesHeader.xml`
  - `xml/IncludesHomeBingie.xml`
  - `xml/screensaver-titan-bingie-mod.xml`
- See `media-src/README.md`.
- 2026-11-11 (D6.1, DEC-NFX-REGULAR-ARTEFACT-01): `media/Textures.xbt` rebuilt from `media-src/textures/` with Kodi's TexturePacker (xbmc `Omega` `f8815ee`, Kodi 21.3.0; `-dupecheck`). Same 1,796 entries, same pixels, dimensions, formats and packed frames; index now byte-sorted and duplicate frames stored once (21,198,498 B → 18,604,280 B; sha256 `453124c7…` → `c8341db6…`). `TEXTURES-MANIFEST.tsv` regenerated. Record: `docs/evidence/D6-SKIN-TEXTURES-REBUILD.md`.

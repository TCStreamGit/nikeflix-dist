# Skin NikeFlix texture sources (`media-src/`)

`media/Textures.xbt` is a built bundle. This folder holds its corresponding source (GPL-2.0 §3) and the tool that reads and writes it.

| Path | What it is |
|---|---|
| `textures/` | One PNG per bundle entry (1,796), at the entry's path. These are the preferred form for editing. |
| `TEXTURES-MANIFEST.tsv` | Per entry: path, width, height, XBT format, sha256 of the stored (LZO-packed) bytes, and sha256 of the decoded BGRA pixels |
| `xbt_tool.py` | A stdlib-only XBTF v2 reader/writer (Python 3.8+). It replaces the legacy Windows "Kodi Texture Tool" executable, which is not carried in this repository. |

## Provenance

- Upstream Titan BINGIE MOD ships only the packed `Textures.xbt`, with no source images.
- `textures/` was produced in T22 (2026-10-18) by `xbt_tool.py extract`, run on the NikeFlix bundle.
- That bundle is the legacy NikeFlix 2.2.8 bundle (1,794 entries) plus two entries that T22 added.
- Every frame in the bundle is format 16 (A8R8G8B8, some with the opaque flag) and LZO1X-compressed. Extraction is lossless: `verify` reports 0 pixel mismatches across all 1,796 entries.

## T22 change to the bundle

T22 added two NikeFlix-named entries. The skin XML now references these instead of the "bingie"-named logos.

| New entry | Pixels identical to (kept) | Used by |
|---|---|---|
| `nikeflix/nikeflix_logo_home.png` (290×170) | `home/bingie_mod_logo.png` | startup windows 1101/1102, header (compact), Home, screensaver |
| `nikeflix/nikeflix_logo.png` (2019×419) | `bingie_mod_logo.png` | header (full) |

- Both legacy logos already showed the NikeFlix artwork; only their names said "bingie".
- In the T22 bundle the new entries were appended after the 1,794 legacy entries, which stayed byte-identical to the legacy bundle (same packed sha256, same order).
- `tests/test_skin_nikeflix.py` checks the bundle index against `TEXTURES-MANIFEST.tsv` whenever the real bundle is checked out (not just a Git LFS pointer).

The old "bingie"/"netflix" logo entries are still in the bundle. The 2026-11-11 rebuild kept the source set exactly as committed (owner decision DEC-NFX-REGULAR-ARTEFACT-01 did not drop them); removing them would be a separate source change after a grep proves nothing in `xml/`, `shortcuts/` or `extras/` references them.

## Commands

```
python media-src/xbt_tool.py list     media/Textures.xbt
python media-src/xbt_tool.py verify   media/Textures.xbt media-src/textures
python media-src/xbt_tool.py manifest media/Textures.xbt > media-src/TEXTURES-MANIFEST.tsv
python media-src/xbt_tool.py extract  media/Textures.xbt <out_dir> [glob ...]
```

To add or replace an entry from a source PNG, run `patch`. It copies every other entry byte-for-byte:

```
python media-src/xbt_tool.py patch media/Textures.xbt out.xbt nikeflix/<name>.png=media-src/textures/nikeflix/<name>.png
```

`patch` stores new pixels uncompressed (A8R8G8B8), which Kodi accepts because the packed and unpacked sizes are equal. If an existing entry has identical pixels, `patch` reuses that entry's packed bytes instead. Keep new artwork small, or rebuild with TexturePacker (below).

The T22 bundle was produced from the legacy bundle (`skin.nikeflix/media/Textures.xbt` at commit `9b42241`) by running:

```
python media-src/xbt_tool.py patch legacy.xbt media/Textures.xbt \
  nikeflix/nikeflix_logo_home.png=media-src/textures/nikeflix/nikeflix_logo_home.png \
  nikeflix/nikeflix_logo.png=media-src/textures/nikeflix/nikeflix_logo.png
```

## Full rebuild from source (done 2026-11-11, D6.1 of DEC-NFX-REGULAR-ARTEFACT-01)

The shipped `media/Textures.xbt` is now built from `textures/` with Kodi's own TexturePacker. Record: `docs/evidence/D6-SKIN-TEXTURES-REBUILD.md`.

- **Tool:** `TexturePacker` compiled from the Kodi source tree `https://github.com/xbmc/xbmc`, branch `Omega`, commit `f8815ee40f49a700c047982d752be4b2a61420e2` (Kodi 21.3.0), path `tools/depends/native/TexturePacker/src`, on Ubuntu 24.04 (WSL) with `liblzo2 2.10`, `libpng 1.6.43`, `giflib 5.2.2`, `libjpeg 8c`:

  ```
  cmake -S xbmc/tools/depends/native/TexturePacker/src -B build -DKODI_SOURCE_DIR=<xbmc> -DCMAKE_BUILD_TYPE=Release "-DARCH_DEFINES=-DTARGET_POSIX;-DTARGET_LINUX"
  cmake --build build
  ```

- **Build command** (the sources copied verbatim to a local directory first):

  ```
  TexturePacker -input <copy of media-src/textures> -output Textures.xbt -dupecheck
  ```

- **Acceptance** (`xbt_tool.py verify Textures.xbt media-src/textures` → `entries: 1796, problems: 0`), then `xbt_tool.py manifest` regenerated `TEXTURES-MANIFEST.tsv`.
- **Result:** sha256 `c8341db662ffe54cabbc97b81f23c770d63769332371f80e64ec2464875326c4`, 18,604,280 B (the T22 bundle was `453124c7d4c9d94ac36229b493ac159be36a6d63813d136642fcf760b49bdd79`, 21,198,498 B). Every entry's path, size, format (1,637 × 16, 159 × 65552) and pixel sha256 is unchanged; every entry's LZO-packed sha256 is also unchanged (LZO1X-999 is deterministic). Only the index order (now byte-sorted by path) and the de-duplicated storage differ, which is where the 2.6 MB went.
- The output is reproducible with this tool and input, but a different TexturePacker build need not produce the same bytes. The record of truth is the committed LFS object's sha256, `verify` → 0 problems, and the manifest.
- Entry names must stay lower-case (Kodi lower-cases lookups; 62 XML references differ from their entry only in case). Check: `cut -f1 media-src/TEXTURES-MANIFEST.tsv | grep -c '[A-Z]'` → `0`.
- Only formats 16 and 65552 (A8R8G8B8, optionally opaque) are acceptable; `xbt_tool.py` decodes nothing else.

`media-src/` ships inside the skin ZIP (D6.2), which meets the GPL-2.0 §3 source duty in-ZIP; no separate source mirror is required for it.

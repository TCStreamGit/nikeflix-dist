"""Stdlib-only reader/writer for Kodi XBTF v2 texture bundles (media/Textures.xbt).

Replaces the legacy Windows "Kodi Texture Tool" executable. Python 3.8+, no third-party modules.

Commands:
  list     <xbt>                         print the index (path, size, format, packed/unpacked bytes)
  extract  <xbt> <out_dir> [glob ...]    write entries as PNG (LZO1X frames are decompressed)
  manifest <xbt>                         print a TSV: path, width, height, format, packed sha256,
                                         pixel sha256 (BGRA after decompression)
  verify   <xbt> <png_dir>               check that every entry has a PNG source with identical pixels
  patch    <xbt> <out_xbt> name=png ...  copy every existing entry byte-for-byte (same order) and add or
                                         replace the named entries from PNG sources. When an existing
                                         entry already holds identical pixels, its LZO-packed bytes are
                                         reused; otherwise the frame is stored uncompressed (A8R8G8B8).

Only single-frame A8R8G8B8 entries (format 16, optionally | XB_FMT_OPAQUE) are decoded or written,
which is the only format the Skin NikeFlix bundle uses. Kodi's own TexturePacker is not required.
"""
import fnmatch, hashlib, os, struct, sys, zlib

MAGIC = b"XBTF"
VERSION = b"2"
FMT_A8R8G8B8 = 16
FMT_OPAQUE = 65536
PATH_LEN = 256
FRAME = struct.Struct("<IIIQQIQ")  # width, height, format, packed, unpacked, duration, offset


class Entry:
    def __init__(self, path, loop, frames):
        self.path, self.loop, self.frames = path, loop, frames  # frames: list of dicts


def read_index(data):
    if data[:4] != MAGIC or data[4:5] != VERSION:
        raise ValueError("not an XBTF v2 bundle")
    count = struct.unpack_from("<I", data, 5)[0]
    pos, entries = 9, []
    for _ in range(count):
        path = data[pos:pos + PATH_LEN].split(b"\0", 1)[0].decode("utf-8")
        pos += PATH_LEN
        loop, nframes = struct.unpack_from("<II", data, pos)
        pos += 8
        frames = []
        for _ in range(nframes):
            w, h, fmt, packed, unpacked, dur, off = FRAME.unpack_from(data, pos)
            pos += FRAME.size
            frames.append(dict(width=w, height=h, format=fmt, packed=packed, unpacked=unpacked,
                               duration=dur, offset=off))
        entries.append(Entry(path, loop, frames))
    return entries, pos


def lzo1x_decompress(src, out_len):
    """LZO1X decompressor (same state machine as Linux lib/lzo/lzo1x_decompress_safe.c)."""
    out = bytearray()
    ip = 0
    n = len(src)

    def copy_match(m_pos, length):
        dist = len(out) - m_pos
        if dist <= 0:
            raise ValueError("lzo: bad match distance")
        if dist >= length:
            out.extend(out[m_pos:m_pos + length])
        else:
            chunk = bytes(out[m_pos:])
            reps, rem = divmod(length, dist)
            out.extend(chunk * reps + chunk[:rem])

    def zero_run(ip):
        start = ip
        while src[ip] == 0:
            ip += 1
        return ip, (ip - start) * 255

    state = 0
    t = src[ip]
    if t > 17:
        ip += 1
        t -= 17
        if t < 4:
            out.extend(src[ip:ip + t]); ip += t
            state = t
        else:
            out.extend(src[ip:ip + t]); ip += t
            state = 4
    while True:
        if ip >= n:
            raise ValueError("lzo: input overrun")
        t = src[ip]; ip += 1
        if t < 16:
            if state == 0:
                if t == 0:
                    ip, extra = zero_run(ip)
                    t = extra + 15 + src[ip]; ip += 1
                t += 3
                out.extend(src[ip:ip + t]); ip += t
                state = 4
                continue
            nxt = t & 3
            if state != 4:
                m_pos = len(out) - 1 - (t >> 2) - (src[ip] << 2); ip += 1
                copy_match(m_pos, 2)
            else:
                m_pos = len(out) - (1 + 0x0800) - (t >> 2) - (src[ip] << 2); ip += 1
                copy_match(m_pos, 3)
        elif t >= 64:
            nxt = t & 3
            m_pos = len(out) - 1 - ((t >> 2) & 7) - (src[ip] << 3); ip += 1
            copy_match(m_pos, (t >> 5) + 1)
        elif t >= 32:
            length = (t & 31) + 2
            if length == 2:
                ip, extra = zero_run(ip)
                length += extra + 31 + src[ip]; ip += 1
            v = src[ip] | (src[ip + 1] << 8); ip += 2
            m_pos = len(out) - 1 - (v >> 2)
            nxt = v & 3
            copy_match(m_pos, length)
        else:
            m_pos = len(out) - ((t & 8) << 11)
            length = (t & 7) + 2
            if length == 2:
                ip, extra = zero_run(ip)
                length += extra + 7 + src[ip]; ip += 1
            v = src[ip] | (src[ip + 1] << 8); ip += 2
            m_pos -= v >> 2
            nxt = v & 3
            if m_pos == len(out):
                break  # end-of-stream marker
            m_pos -= 0x4000
            copy_match(m_pos, length)
        state = nxt
        if nxt:
            out.extend(src[ip:ip + nxt]); ip += nxt
    if len(out) != out_len:
        raise ValueError("lzo: size mismatch %d != %d" % (len(out), out_len))
    return bytes(out)


def frame_pixels(data, frame):
    raw = data[frame["offset"]:frame["offset"] + frame["packed"]]
    if frame["packed"] != frame["unpacked"]:
        raw = lzo1x_decompress(raw, frame["unpacked"])
    return raw


def _png_chunk(tag, body):
    return struct.pack(">I", len(body)) + tag + body + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)


def bgra_to_png(width, height, bgra):
    rows = bytearray()
    stride = width * 4
    for y in range(height):
        row = bytearray(bgra[y * stride:(y + 1) * stride])
        row[0::4], row[2::4] = row[2::4], row[0::4]  # BGRA -> RGBA
        rows += b"\0" + row
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + _png_chunk(b"IHDR", ihdr) +
            _png_chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + _png_chunk(b"IEND", b""))


def png_to_bgra(path):
    """Decode an 8-bit, non-interlaced RGB or RGBA PNG to (width, height, BGRA bytes)."""
    data = open(path, "rb").read()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG: %s" % path)
    pos, idat, ihdr = 8, bytearray(), None
    while pos < len(data):
        length = struct.unpack_from(">I", data, pos)[0]
        tag = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if tag == b"IHDR":
            ihdr = struct.unpack(">IIBBBBB", body)
        elif tag == b"IDAT":
            idat += body
        elif tag == b"IEND":
            break
    width, height, depth, ctype, _, _, interlace = ihdr
    if depth != 8 or ctype not in (2, 6) or interlace:
        raise ValueError("unsupported PNG (need 8-bit RGB/RGBA, non-interlaced): %s" % path)
    bpp = 4 if ctype == 6 else 3
    raw = zlib.decompress(bytes(idat))
    stride = width * bpp
    prev = bytearray(stride)
    out = bytearray()
    pos = 0
    for _ in range(height):
        ftype = raw[pos]; pos += 1
        line = bytearray(raw[pos:pos + stride]); pos += stride
        for i in (range(stride) if ftype else ()):
            a = line[i - bpp] if i >= bpp else 0
            b = prev[i]
            c = prev[i - bpp] if i >= bpp else 0
            if ftype == 1:
                line[i] = (line[i] + a) & 255
            elif ftype == 2:
                line[i] = (line[i] + b) & 255
            elif ftype == 3:
                line[i] = (line[i] + ((a + b) >> 1)) & 255
            elif ftype == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pred = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                line[i] = (line[i] + pred) & 255
        prev = line
        if bpp == 4:
            px = line
        else:
            px = bytearray(width * 4)
            px[0::4], px[1::4], px[2::4], px[3::4] = line[0::3], line[1::3], line[2::3], b"\xff" * width
        px[0::4], px[2::4] = px[2::4], px[0::4]  # RGBA -> BGRA
        out += px
    return width, height, bytes(out)


def write_bundle(out_path, entries, payloads):
    """entries: list of Entry; payloads: list (parallel to frames) of raw frame bytes."""
    header_size = 9 + sum(PATH_LEN + 8 + FRAME.size * len(e.frames) for e in entries)
    offset = header_size
    index = bytearray(MAGIC + VERSION + struct.pack("<I", len(entries)))
    blobs = []
    for entry, frames_payload in zip(entries, payloads):
        path = entry.path.encode("utf-8")
        if len(path) >= PATH_LEN:
            raise ValueError("path too long: %s" % entry.path)
        index += path.ljust(PATH_LEN, b"\0") + struct.pack("<II", entry.loop, len(entry.frames))
        for frame, blob in zip(entry.frames, frames_payload):
            index += FRAME.pack(frame["width"], frame["height"], frame["format"], len(blob),
                                frame["unpacked"], frame["duration"], offset)
            offset += len(blob)
            blobs.append(blob)
    assert len(index) == header_size
    with open(out_path, "wb") as fh:
        fh.write(index)
        for blob in blobs:
            fh.write(blob)


def is_rgba_frame(entry):
    return len(entry.frames) == 1 and (entry.frames[0]["format"] & 0xFFFF) == FMT_A8R8G8B8


def patch(src_path, out_path, replacements):
    data = open(src_path, "rb").read()
    entries, _ = read_index(data)
    by_path = {e.path.lower(): i for i, e in enumerate(entries)}
    payloads = [[data[f["offset"]:f["offset"] + f["packed"]] for f in e.frames] for e in entries]
    for name, png in replacements:
        name = name.lower()
        w, h, bgra = png_to_bgra(png)
        digest = hashlib.sha256(bgra).digest()
        frame = dict(width=w, height=h, format=FMT_A8R8G8B8, packed=len(bgra), unpacked=len(bgra),
                     duration=0, offset=0)
        blob = bgra
        for other in entries:  # reuse identical, already LZO-packed pixels when available
            f = other.frames[0] if other.frames else None
            if f and is_rgba_frame(other) and (f["width"], f["height"]) == (w, h) and                     hashlib.sha256(frame_pixels(data, f)).digest() == digest:
                frame = dict(f)
                blob = data[f["offset"]:f["offset"] + f["packed"]]
                break
        entry = Entry(name, 0, [frame])
        if name in by_path:
            i = by_path[name]
            entries[i], payloads[i] = entry, [blob]
        else:
            by_path[name] = len(entries)
            entries.append(entry)
            payloads.append([blob])
    write_bundle(out_path, entries, payloads)


def manifest_rows(data):
    entries, _ = read_index(data)
    for e in entries:
        for f in e.frames:
            packed = data[f["offset"]:f["offset"] + f["packed"]]
            pixels = frame_pixels(data, f) if is_rgba_frame(e) else b""
            yield (e.path, f["width"], f["height"], f["format"], hashlib.sha256(packed).hexdigest(),
                   hashlib.sha256(pixels).hexdigest() if pixels else "-")


def verify(xbt_path, png_dir):
    data = open(xbt_path, "rb").read()
    entries, _ = read_index(data)
    problems = []
    for e in entries:
        if not is_rgba_frame(e):
            problems.append("unsupported entry format: %s" % e.path)
            continue
        src = os.path.join(png_dir, *e.path.split("/"))
        if not os.path.exists(src):
            problems.append("missing source: %s" % e.path)
            continue
        w, h, bgra = png_to_bgra(src)
        f = e.frames[0]
        if (w, h) != (f["width"], f["height"]) or bgra != frame_pixels(data, f):
            problems.append("pixel mismatch: %s" % e.path)
    return len(entries), problems


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    cmd = argv[0]
    if cmd == "list":
        data = open(argv[1], "rb").read()
        entries, _ = read_index(data)
        for e in entries:
            for f in e.frames:
                print("%s\t%dx%d\tfmt=%d\tpacked=%d\tunpacked=%d" % (
                    e.path, f["width"], f["height"], f["format"], f["packed"], f["unpacked"]))
        return 0
    if cmd == "extract":
        data = open(argv[1], "rb").read()
        out_dir, globs = argv[2], argv[3:] or ["*"]
        entries, _ = read_index(data)
        for e in entries:
            if not any(fnmatch.fnmatch(e.path.lower(), g.lower()) for g in globs):
                continue
            f = e.frames[0]
            if len(e.frames) != 1 or (f["format"] & 0xFFFF) != FMT_A8R8G8B8:
                print("skip (unsupported format): %s" % e.path)
                continue
            target = os.path.join(out_dir, *e.path.split("/"))
            os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
            with open(target, "wb") as fh:
                fh.write(bgra_to_png(f["width"], f["height"], frame_pixels(data, f)))
            print(target)
        return 0
    if cmd == "manifest":
        data = open(argv[1], "rb").read()
        print("path	width	height	format	packed_sha256	pixels_sha256")
        for row in manifest_rows(data):
            print("	".join(str(c) for c in row))
        return 0
    if cmd == "verify":
        count, problems = verify(argv[1], argv[2])
        for p in problems:
            print(p)
        print("entries: %d, problems: %d" % (count, len(problems)))
        return 1 if problems else 0
    if cmd == "patch":
        pairs = [a.split("=", 1) for a in argv[3:]]
        patch(argv[1], argv[2], pairs)
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

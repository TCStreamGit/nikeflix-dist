# -*- coding: utf-8 -*-
# NikeFlix H3 switch quiescence (Option C, DEC-H3-C-STAGING). Copied unchanged into each
# patched service add-on; license follows the host add-on (all six are GPL/MIT-compatible with this notice).
"""Let a background poll loop stand still while a NikeFlix profile switch is pending.

Kodi 21.3 holds its frame-move guard for the whole System.LogOff / LoadProfile. `xbmc.getCondVisibility` (and the
other GuiLock calls) from a service thread then blocks until Kodi kills the service after 5 s. While `pending()`
is True a poll loop skips its pass; it never answers a GUI condition with a made-up value.

Three requests, all in Window(Home).Property(nikeflix.quiesce):
* "switch:<hh:mm:ss>" - set by the skin's Switch-profile click itself (local time), together with the one LogOff
  alarm. Honoured for at most BUTTON_MAX_S, so even a switch that service.nikeflix never takes over (disabled,
  crashed, not started yet) finds the loops parked when the alarm's LogOff comes. No acknowledgement.
* "<deadline epoch seconds>:<token>" - set by service.nikeflix's switch sequence (quiesce.py) before it lets the
  skin's one LogOff alarm fire. The loop acknowledges the token in nikeflix.quiesce.ack.<slot>.
* "login:<hh:mm:ss>" - set by the skin's LoginScreen.xml <onload> with the local time, cleared <onunload>. Services
  running from the master profile (also those still starting up) have nothing to poll on the login screen, and the
  profile picked next is loaded with them idle. Honoured for at most LOGIN_MAX_S after it was set.

Lock safety: only Home *window properties* are used. They take the gfx lock through SingleLockWithDelayGuard,
which releases the Python GIL first. NEVER call xbmcgui.getCurrentWindowId()/getCurrentWindowDialogId() or
xbmc.getCondVisibility() here: they also release the GIL, but then wait for the gfx lock or the frame-move guard,
which Kodi holds during LogOff, so the caller blocks until it is killed. (The first candidate called
getCurrentWindowId() and deadlocked in Kodi's kill path in lab smoke 1. An earlier note blamed a GIL held while
waiting; the 21.3 source does not support that - DelayedCallGuard releases it - so that deadlock's exact cause
is open. The call stays banned because it blocks.)

Fail-safe by construction:
* a deadline request ends by itself (failed LogOff, interrupted switch); past, malformed or more than MAX_S ahead
  (clock jump) counts as no request;
* a "switch" marker older than BUTTON_MAX_S (or unparsable, e.g. an unexpanded $INFO) is ignored;
* a "login" marker older than LOGIN_MAX_S (or unparsable) is ignored, so a leftover marker cannot park a service
  for long; <onunload> clears it anyway. (A first version only honoured the marker in
  services that had seen no request before; lab smoke 3 showed services that start late - while the login screen
  is already up - then poll on and get killed.)
* Home properties do not survive a Kodi restart;
* the property holds only a time and a random token (or "login") - no profile, path or credential;
* any error means "not pending", i.e. today's behaviour.
"""
import time

import xbmc
import xbmcgui

PROPERTY = "nikeflix.quiesce"
ACK_PREFIX = "nikeflix.quiesce.ack."
LOGIN = "login"
LOGIN_MAX_S = 600.0
BUTTON = "switch"
BUTTON_MAX_S = 90.0   # the skin's 40-s fallback LogOff plus the time Kodi needs to stop the services
WINDOW_HOME = 10000
MAX_S = 90.0   # longest request the initiator sets: SAFETY_CAP_S 45 + 30 s margin (75 s), plus slack

_home = []
_paused = {}
_kind = {}


def parse(value, now):
    """(deadline, token) when `value` is a live, bounded deadline request at time `now`, else None."""
    if not value:
        return None
    deadline, sep, token = value.partition(":")
    if not sep or not token:
        return None
    try:
        left = float(deadline) - now
    except ValueError:
        return None
    if 0.0 < left <= MAX_S:
        return float(deadline), token
    return None


def login_age(value, now_local, tag_wanted=LOGIN):
    """Seconds since a "<tag>:<hh:mm:ss>" marker ("login" or "switch") was set (local wall clock, across midnight),
    else None."""
    tag, sep, stamp = value.partition(":")
    if tag != tag_wanted or not sep:
        return None
    try:
        h, m, sec = (int(x) for x in stamp.strip().split(":"))
    except ValueError:
        return None
    if not (0 <= h < 24 and 0 <= m < 60 and 0 <= sec < 60):
        return None
    now_s = now_local.tm_hour * 3600 + now_local.tm_min * 60 + now_local.tm_sec
    # Kodi's System.Time(hh:mm:ss) follows the region's clock and may be 12-hour (13:09 -> "01:09"; lab
    # 2026-10-20): read the hour both ways and keep the younger age.
    return min((now_s - ((hh % 24) * 3600 + m * 60 + sec)) % 86400 for hh in (h, h + 12))


def _window():
    if not _home:
        _home.append(xbmcgui.Window(WINDOW_HOME))
    return _home[0]


def pending(slot):
    """True while a switch is pending (bounded) or the login screen is up. Acknowledges each deadline token once
    for `slot`; logs only pause/resume transitions."""
    paused = False
    kind = "error"
    try:
        home = _window()
        value = home.getProperty(PROPERTY)
        if value.startswith(LOGIN):
            age = login_age(value, time.localtime())
            paused = age is not None and age <= LOGIN_MAX_S
            kind = "login" if paused else "login-stale"
        elif value.startswith(BUTTON + ":"):
            # the skin's own marker, set by the Switch-profile click itself: pauses even when service.nikeflix
            # never takes the switch over (the 40-s fallback LogOff then still finds every loop parked)
            age = login_age(value, time.localtime(), BUTTON)
            paused = age is not None and age <= BUTTON_MAX_S
            kind = "button" if paused else "button-stale"
        else:
            live = parse(value, time.time())
            if live:
                kind = "switch"
                paused = True
                if home.getProperty(ACK_PREFIX + slot) != live[1]:
                    home.setProperty(ACK_PREFIX + slot, live[1])
            else:
                kind = "none" if not value else "expired-or-invalid"
    except Exception:   # never let the helper stop a service; worst case is today's behaviour
        paused = False
    if kind != _kind.get(slot):
        _kind[slot] = kind
        xbmc.log("[nikeflix.quiesce] %s sees %s" % (slot, kind), xbmc.LOGDEBUG)
    if paused != _paused.get(slot, False):
        _paused[slot] = paused
        xbmc.log("[nikeflix.quiesce] %s %s" % (slot, "paused" if paused else "resumed"), xbmc.LOGINFO)
    return paused

# NikeFlix changes to plugin.video.umbrella

This add-on is redistributed by NikeFlix under its original licence (GPL-3.0-only).

- Upstream: https://github.com/umbrellaplug/umbrellaplug.github.io (zips only; no public source repo found) 6.7.92
- Upstream ZIP: https://raw.githubusercontent.com/umbrellaplug/umbrellaplug.github.io/master/omega/zips/plugin.video.umbrella/plugin.video.umbrella-6.7.92.zip
- Upstream sha256: 8dc3b19e70d0e02deb32d06579441288dbe1911ecaec2628d298590e1333853f
- NikeFlix version: 6.7.92+nikeflix.3

## Patches

- `0001-h3-switch-quiescence.patch`: H3 Option C follow-up: the account-sync service loop (resources/lib/modules/tools.py services_syncs) skips its pass, makes no GUI condition call and acknowledges while a NikeFlix profile switch is pending; its 5-s and 30-s waits return early on a pending switch, so Kodi does not have to kill Umbrella during LogOff (about 1 in 6 switches before). Adds the shared nikeflix_quiesce.py unchanged. Evidence docs/evidence/H3-UMBRELLA-PAUSE.md.
- `0002-quiet-mode-opensubs-no-account.patch`: Quiet Mode step 2 (T34 site UMB-OPENSUBS-AUTH, Subtitles.get): with no OpenSubtitles account in Umbrella and service.nikeflix quiet.enabled on, playback start no longer toasts 'Unable to authorize opensubs' and logs 'NikeFlix Quiet Mode: hid ...' instead; Quiet Mode off, a missing service.nikeflix or an entered account that fails behave as upstream. Evidence docs/evidence/T34-QUIET-MODE-STEP2.md.
